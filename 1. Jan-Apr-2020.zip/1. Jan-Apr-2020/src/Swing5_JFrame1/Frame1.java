package Swing5_JFrame1;
import javax.swing.JFrame;

public class Frame1 {	
	public static void main(String args[])
	{
		JFrame frame=new JFrame();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// it terminates the program when the cross button is clicked
		
		//frame.setSize(500,300);
		
		//frame.setLocationRelativeTo(null); //it takes the frame in center of a computer screen
		
		//frame.setLocation(300, 400);
	
		frame.setBounds(300, 300, 400, 500);//combination of setBounds and setLocation method
	
		frame.setTitle("Title:Frame-UODA");
		
		frame.setResizable(false);// the resizable option will be disabled
	}
	

}
