package Swing5_JFrame1;
// create JTextField
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;


public class Frame10 extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JTextField t1,t2,t3;
	
	Frame10()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.cyan);
		
		t1=new JTextField("Hello Textfield!");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
		t2=new JTextField();
		t2.setBounds(50,100,100,30);
		c.add(t2);
		
		t3=new JTextField();
		t3.setBounds(50,150,200,30);
		c.add(t3);
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame10 frame=new Frame10();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Title:Create JLabel");
		
	}

	
}
