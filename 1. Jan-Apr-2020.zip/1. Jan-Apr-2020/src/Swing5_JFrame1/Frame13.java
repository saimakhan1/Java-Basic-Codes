package Swing5_JFrame1;
// JTextField Alignment
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;


public class Frame13 extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JTextField t1,t2,t3;
	private Font f,f2,f3;//declare font
	
	Frame13()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.green);
		
		f=new Font("Arial",Font.ITALIC,16); //font name,style and size
		f2=new Font("Verdana",Font.BOLD,20); //font name,style and size
		f3=new Font("Verdana",Font.ITALIC+Font.BOLD,16);
		
		t1=new JTextField("Hello Textfield!");
		t1.setBounds(50,50,100,30);
		t1.setFont(f);
		c.add(t1);
		
		t2=new JTextField();
		t2.setBounds(50,100,100,30);
		t2.setFont(f2);
		t2.setForeground(Color.RED);
		t2.setBackground(Color.blue);
		t2.setHorizontalAlignment(JTextField.CENTER);
		c.add(t2);
		
		t3=new JTextField();
		t3.setBounds(50,150,200,30);
		t3.setFont(f3);
		t3.setHorizontalAlignment(JTextField.RIGHT);
		c.add(t3);
		
		
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame13 frame=new Frame13();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Title:Create JLabel");
		
	}

	
}
