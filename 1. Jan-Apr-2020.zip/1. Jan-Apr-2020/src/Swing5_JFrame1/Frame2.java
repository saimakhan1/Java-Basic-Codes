package Swing5_JFrame1;
import javax.swing.JFrame;

public class Frame2 extends JFrame{
	
	Frame2()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50,100,400,500);
		setTitle("Title:JFrame2");
	}
	
	public static void main(String args[])
	{
		Frame2 frame=new Frame2();
		frame.setVisible(true);
		
	}

}
