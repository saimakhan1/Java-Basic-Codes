package Swing5_JFrame1;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Frame3_changeIcon extends JFrame{	
	private ImageIcon icon;
	
	Frame3_changeIcon()
	{
		all_methods();
	}
	
	public void all_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));
		this.setIconImage(icon.getImage());
	}
	
	public static void main(String args[])
	{
		Frame3_changeIcon frame=new Frame3_changeIcon();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Changing Icon");	
	}	
}
