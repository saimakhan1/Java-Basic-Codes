package Swing5_JFrame1;
// task is do change the background color of frame.
/*/ Then, we need to import containe.. and we need to declare container and keep the color in 
container*/

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Container;

public class Frame4 extends JFrame{
	
	private ImageIcon icon;
	private Container c;
	
	Frame4()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//change background color
		c.setBackground(Color.magenta);//change background color
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame4 frame=new Frame4();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,300);
		frame.setTitle("Title:JFrame2");
		
	}

	
}
