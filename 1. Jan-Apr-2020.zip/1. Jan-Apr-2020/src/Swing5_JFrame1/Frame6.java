package Swing5_JFrame1;
// Task here is to create multiple JLabel
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel

import java.awt.Color;
import java.awt.Container;

public class Frame6 extends JFrame{
	
	private ImageIcon icon;
	private Container c;
	private JLabel label1,label2; //declare variable of JLabel
	
	Frame6()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		c.setBackground(Color.green);//change background color
		
		//JLabel codes go below
		c.setLayout(null);//to make the layout null and now  won't be at he border and it won't be displayed
		
		label1=new JLabel();//create object of JLabel
		label1.setText("Enter your Name: ");//set text in JLabel
		label1.setBounds(50,50,100,100);//Now it will show the JLabel
		c.add(label1);//add the label in container//by default it will be in border
		
		label2=new JLabel();
		label2.setText("Enter Your ID: ");
		label2.setBounds(50,100,100,100);
		c.add(label2);
		
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame6 frame=new Frame6();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,300);
		frame.setTitle("Title:Create JLabel");
		
	}

	
}
