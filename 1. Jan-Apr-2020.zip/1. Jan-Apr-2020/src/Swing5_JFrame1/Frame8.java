package Swing5_JFrame1;
// Change foreground and background color of JLabel
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;

public class Frame8 extends JFrame{
	
	private ImageIcon icon;
	private Container c;
	private JLabel label1,label2; //declare variable of JLabel
	private Font f;//to create font
	
	Frame8()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		c.setBackground(Color.gray);//change background color
		
		f=new Font("Arial",Font.BOLD,20);//changing font size and style
		
		//JLabel codes go below
		c.setLayout(null);//to make the layout null and now  won't be at he border and it won't be displayed
		
		label1=new JLabel();//create object of JLabel
		label1.setText("Enter your Name: ");//set text in JLabel
		label1.setBounds(50,50,180,70);//Now it will show the JLabel
		label1.setToolTipText("Hello!tooltip1! ");
		
		label1.setForeground(Color.RED);// change foreground color
		label1.setOpaque(true);//used to change background color
		label1.setBackground(Color.black);//used to change background color
		
		c.add(label1);//add the label in container//by default it will be in border
		
		label1.setFont(f);//add font size
		
		label2=new JLabel();
		label2.setText("Enter Your ID: ");
		label2.setBounds(50,150,100,100);
		c.add(label2);
		
		//System.out.println(label1.getText());
		//System.out.println(label1.getToolTipText());
		
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame8 frame=new Frame8();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Title:Create JLabel");
		
	}

	
}
