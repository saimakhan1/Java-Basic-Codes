package Swing5_JFrame1;
// Add a background Image
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;


public class Frame9 extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JLabel label1,label2; //declare variable of JLabel
	private Font f;//to create font
	
	Frame9()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		icon2=new ImageIcon(getClass().getResource("vlc2.PNG"));//add background image
		imageLabel=new JLabel(icon2);//add background image
		//imageLabel.setBounds(50, 50, 10, 750);//add background image
		imageLabel.setBounds(50, 50, icon2.getIconWidth(), icon2.getIconHeight());//add background image
		c.add(imageLabel);//add image background
			
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame9 frame=new Frame9();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,700,500);
		frame.setTitle("Title:Create JLabel");
		
	}

	
}
