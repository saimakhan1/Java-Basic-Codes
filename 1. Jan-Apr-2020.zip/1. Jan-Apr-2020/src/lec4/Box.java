package lec4;

public class Box {
	double height, width, depth;
	Box(double h, double w, double d)
	{
		height=h;
		width=w;
		depth=d;
		
	}
	
	double volume()
	{
		return width*height*depth;
	}

}
