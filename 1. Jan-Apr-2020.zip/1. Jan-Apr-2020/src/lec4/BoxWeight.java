package lec4;

public class BoxWeight extends Box{
	
	double weight;
	
	BoxWeight(double h,double w, double d, double w2)
	{
		super(h,w,d);
		weight=w2;
	}

}
