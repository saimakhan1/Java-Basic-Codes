package lec4;

public class DemoShipment{
	
	public static  void main(String args[])
	{
		Shipment s1=new Shipment(10,20,30,40,2);
		
		Shipment s2=new Shipment(1,2,3,4,5);
		
		double vol;
		vol=s1.volume();
		
		System.out.println("Volume is: "+vol);
		System.out.println("Weight is "+s1.weight);
		System.out.println("Cost is "+s1.cost);
		
	}

}
