package lec4;

public class Shipment extends BoxWeight{
	
	double cost;
	
	Shipment(double h,double w, double d, double w2,double c)
	{
		super(h,w,d,w2);
		cost=c;
	}

}
