package lec5;


class A
{
	
	void mymethod()
	{
		System.out.println("Parent class");
	}
}
public class B extends A{

	void mymethod()
	{
		System.out.println("\n------\n");
		super.mymethod();
		System.out.println("Child class");
		System.out.println("\n------\n");
	}
	
	public static void main(String args[])
	{
		B ob1=new B();
		
		A ob2=new A();
		//B ob3=new A();//error
		A ob3=new B();
		
		ob1.mymethod();
		ob2.mymethod();
		ob3.mymethod();
		
		
	}
	
}
