package swing1;

import javax.swing.JOptionPane;

public class Dialog1 {

	public static void main(String args[])
	{
		JOptionPane.showMessageDialog(null,"Congratulation");
	}
}
