package swing1;

import javax.swing.JOptionPane;

public class Dialog2 {
	public static void main(String args[])
	{
		JOptionPane.showMessageDialog(null,"Congratulation", "Result",JOptionPane.ERROR_MESSAGE);
		
		JOptionPane.showMessageDialog(null,"Congratulation", "Result",JOptionPane.QUESTION_MESSAGE);
		
		JOptionPane.showMessageDialog(null,"Congratulation", "Result",JOptionPane.PLAIN_MESSAGE);
		
		JOptionPane.showMessageDialog(null,"Congratulation", "Result",2);
	}
	
	// 1st parameter - position of window
	//2nd parameter - message
	//3rd parameter - title at the window
	//4th parameter - defines icon
	//instead of 4th elaborate parameter, a code can be used in 4th parameter. 

}
