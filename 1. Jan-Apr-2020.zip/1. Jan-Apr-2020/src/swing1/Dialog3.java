package swing1;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class Dialog3 {
	
	public static void main(String args[])
	{
		
		ImageIcon icon1=new ImageIcon("vlc.PNG");
		
		JOptionPane.showMessageDialog(null,"Add customized icon", "Title-Hello",
				JOptionPane.PLAIN_MESSAGE,icon1);
		
			}
	
}
