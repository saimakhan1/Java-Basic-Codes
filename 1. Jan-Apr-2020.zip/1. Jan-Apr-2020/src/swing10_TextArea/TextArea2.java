package swing10_TextArea;
import java.awt.Container;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import java.awt.Color;
// changing font, font type, font size 
public class TextArea2 extends JFrame{
	private Container c;
	private JTextArea t1;
	private Font f1;
	
	TextArea2()
	{
		components();
	}
	
	public void components()
	{
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.orange);
		
		//f1=new Font("Arial", Font.BOLD,18);
		f1=new Font("Arial", Font.ITALIC,24);
		
		t1=new JTextArea();
		t1.setBounds(50, 50, 200, 50);
		t1.setFont(f1);
		c.add(t1);
		
	}
	
	public static void main(String args[])
	{
		TextArea2 fr1=new TextArea2();
		fr1.setVisible(true);
		fr1.setBounds(100, 100, 400, 400);
		fr1.setTitle("TextArea");
		fr1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
}
