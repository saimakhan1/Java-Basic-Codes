package swing10_TextArea;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import java.awt.Color;
// Creating TextArea

public class TextArea3 extends JFrame{
	private Container c;
	private JTextArea t1;
	
	TextArea3()
	{
		components();
	}
	
	public void components()
	{
		c=this.getContentPane();
		c.setLayout(null);
		//c.setBackground(Color.orange);
		
		t1=new JTextArea();
		t1.setBounds(50, 50, 200, 70);
		c.add(t1);
		
	}
	
	public static void main(String args[])
	{
		TextArea3 fr1=new TextArea3();
		fr1.setVisible(true);
		fr1.setBounds(100, 100, 400, 400);
		fr1.setTitle("TextArea");
		fr1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
}
