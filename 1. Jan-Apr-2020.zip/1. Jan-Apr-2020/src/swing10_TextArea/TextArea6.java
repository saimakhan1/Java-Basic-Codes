package swing10_TextArea;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import java.awt.Color;
// Line Wrapping and here all the words are complete 

public class TextArea6 extends JFrame{
	private Container c;
	private JTextArea t1;
	
	TextArea6()
	{
		components();
	}
	
	public void components()
	{
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.gray);
		
		t1=new JTextArea();
		t1.setBounds(50, 50, 200, 50);
		
		t1.setLineWrap(true);
		t1.setWrapStyleWord(true);
		
		
		c.add(t1);
		
	}
	
	public static void main(String args[])
	{
		TextArea6 fr1=new TextArea6();
		fr1.setVisible(true);
		fr1.setBounds(100, 100, 400, 400);
		fr1.setTitle("TextArea");
		fr1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
}
