package swing11_MultiplicationTable;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Frame1 extends JFrame{
	
	private Container c;
	private JLabel l1, l2;
	private JTextArea ta1;
	private JTextField tf1;
	private JButton clear;
	private ImageIcon img; 
	private Font f1; 
	private Cursor cursor;
	
	Frame1()
	{
	
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 100, 350,600);
		this.setTitle("Multiplication Table");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		f1=new Font("Tahoma",Font.BOLD,16);
		
		img=new ImageIcon(getClass().getResource("calculator.PNG"));
		
		l1=new JLabel(img);
		//l1.setBounds(10,10, img.getIconWidth(), img.getIconHeight());
		l1.setBounds(10,10, 300, 170);
		c.add(l1);

		l2=new JLabel("Enter a Number: ");
		l2.setBounds(50,100, 250,200);
		l2.setForeground(Color.blue);
		l2.setFont(f1);
		c.add(l2);
		
		tf1=new JTextField();
		tf1.setBounds(200,190,80, 30);
		tf1.setBackground(Color.pink);
		tf1.setHorizontalAlignment(JTextField.CENTER);
		tf1.setFont(f1);
		c.add(tf1);
		
		cursor=new Cursor(Cursor.HAND_CURSOR);
		
		clear =new JButton("Clear");
		clear.setBounds(200,230,80, 30);
		
		clear.setCursor(cursor);
		clear.setBackground(Color.magenta);
		clear.setFont(f1);
		c.add(clear);
		
		ta1=new JTextArea();
		ta1.setBounds(25,290,280,250);
		ta1.setBackground(Color.pink);
		ta1.setFont(f1);
		c.add(ta1);
		
		tf1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				String value=tf1.getText();
				if (value.isEmpty())
				{
					JOptionPane.showMessageDialog(null, "Empty Content");
				}
				else
				{
					ta1.setText(null);// each time the text area will be empty other wise it will contain all the inputs
					int num= Integer.parseInt(tf1.getText());
					for(int i=1;i<=10;i++)
					{
						
						int result=num*i;
						
						String r= String.valueOf(result);
						String n=String.valueOf(num);
						String increment=String.valueOf(i);
						
						ta1.append(n+ "X"+ increment+ " = "+r+"\n" );
					}	
				}
				
			}
		});
		
		clear.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				ta1.setText("");
			}
		});
	}
	
	public static void main(String args[])
	{
		Frame1 f1=new Frame1();
		f1.setVisible(true);
	}

}
