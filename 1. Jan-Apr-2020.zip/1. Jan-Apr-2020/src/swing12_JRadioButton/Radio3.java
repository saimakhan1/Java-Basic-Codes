package swing12_JRadioButton;
import javax.swing.ButtonGroup;

import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton; 
//Button Group-> that helps to choose 1 button instead of 2 radio button
public class Radio3 extends JFrame{
	private Container c;
	private JRadioButton male, female;
	private ButtonGroup group1;
 
	
	Radio3()
	{
		components();
	}
	
	public void components()
	{
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.GRAY);
		
		group1=new ButtonGroup();
		
		male=new JRadioButton("Male");
		male.setBounds(50,50,100,50);
		male.setBackground(Color.gray);
		c.add(male);
		
		female=new JRadioButton("Female");
		female.setBounds(170,50,100,50);
		female.setBackground(Color.GRAY);
		c.add(female);
		
		group1.add(male);
		group1.add(female);
	}
	
	public static void main(String args[])
	{
		Radio3 frame=new Radio3();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(150,100,400,500);
		frame.setTitle("JRadio Button");
		
	}

}
