package swing12_JRadioButton;
import javax.swing.ButtonGroup;


import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;

import javax.swing.JPasswordField;
import javax.swing.JRadioButton; 
//Disable a button
public class Radio5 extends JFrame{
	private Container c;
	private JRadioButton male, female;
	private ButtonGroup group1;
	private Font f;
 
	
	Radio5()
	{
		components();
	}
	
	public void components()
	{
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.GRAY);
		
		f=new Font("Arial",Font.BOLD,18);
		group1=new ButtonGroup();
		
		male=new JRadioButton("Male");
		male.setBounds(50,50,100,50);
		male.setFont(f);
		male.setBackground(Color.gray);
		male.setSelected(true);
		c.add(male);
		
		female=new JRadioButton("Female");
		female.setBounds(170,50,100,50);
		female.setFont(f);
		female.setBackground(Color.GRAY);
		female.setEnabled(false);
		c.add(female);
		
		group1.add(male);
		group1.add(female);
	}
	
	public static void main(String args[])
	{
		Radio5 frame=new Radio5();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(150,100,400,500);
		frame.setTitle("JRadio Button");
		
	}

}
