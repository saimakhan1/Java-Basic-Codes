package swing12_JRadioButton;
import javax.swing.ButtonGroup;


import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea; 
//Adding Action Listener
public class Radio9 extends JFrame{
	private Container c;
	private JRadioButton male, female;
	private ButtonGroup group1;
	private Font f;
	private JTextArea ta1;
 
	
	Radio9()
	{
		components();
	}
	
	public void components()
	{
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.GRAY);
		
		f=new Font("Arial",Font.BOLD,18);
		group1=new ButtonGroup();
		
		male=new JRadioButton("Male");
		male.setBounds(50,50,100,50);
		male.setFont(f);
		male.setBackground(Color.gray);
		//male.setSelected(true);
		c.add(male);
		
		female=new JRadioButton("Female");
		female.setBounds(170,50,100,50);
		female.setFont(f);
		female.setBackground(Color.GRAY);
		
		c.add(female);
		
		group1.add(male);
		group1.add(female);
		
		ta1=new JTextArea();
		ta1.setBounds(50,100,250,100);
		ta1.setFont(f);
		ta1.setBackground(Color.PINK);
		c.add(ta1);
		
		action action1=new action();
		male.addActionListener(action1);
		female.addActionListener(action1);
	}
	
	class action implements ActionListener{
		public void actionPerformed(ActionEvent ae) {
			
			if(male.isSelected())
				ta1.append("You have selcted male\n");
			else
				ta1.append("You have selected female\n");
			
			}
	}
	
	
	public static void main(String args[])
	{
		Radio9 frame=new Radio9();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(150,100,400,500);
		frame.setTitle("JRadio Button");
		
	}

}
