package swing13_JCheckBox;
import java.awt.Color;
import java.awt.Container;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Adding ButtonGroup
public class Checkbox2 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JCheckBox ch1, ch2, ch3;
	private ButtonGroup group1;
	
	Checkbox2()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(200, 150, 450,450);
		this.setTitle("CheckBox");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		group1=new ButtonGroup();
		
		ch1=new JCheckBox("CSE");
		ch1.setBounds(20, 20,100, 50);
		ch1.setBackground(Color.pink);
		c.add(ch1);
		
		ch2=new JCheckBox("EEE");
		ch2.setBounds(20, 60,100, 50);
		ch2.setBackground(Color.CYAN);
		c.add(ch2);
		
		ch3=new JCheckBox("ETE");
		ch3.setBounds(20, 100,100, 50);
		ch3.setBackground(Color.GRAY);
		c.add(ch3);
		
		group1.add(ch1);
		group1.add(ch2);
		group1.add(ch3);
	}
	
	public static void main(String args[])
	{
		Checkbox2 f1=new Checkbox2();
		f1.setVisible(true);
	}

}
