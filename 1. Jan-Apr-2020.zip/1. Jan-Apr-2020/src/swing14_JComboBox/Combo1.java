package swing14_JComboBox;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

// create combox and add some items in the box
// option for editing comboBox (in comment)
public class Combo1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JComboBox cb1;
	private String [] cars= {"Volvo", "BMW", "Corola", "Alien", "Mercedes"};
	
	Combo1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("JComboBox");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		/*l1=new JLabel("Hello");
		l1.setBounds(20, 20, 100, 50);
		c.add(l1);*/
		

		cb1=new JComboBox(cars);
		cb1.setBounds(20, 20, 100, 50);
		//cb1.setEditable(true);
		c.add(cb1);
	}
	
	public static void main(String args[])
	{
		Combo1 f1=new Combo1();
		f1.setVisible(true);
	}

}
