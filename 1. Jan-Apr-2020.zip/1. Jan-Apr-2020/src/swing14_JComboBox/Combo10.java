package swing14_JComboBox;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Adding Action Listener with Combo Box
// showing message using button

public class Combo10 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JComboBox cb1;
	private String [] cars= {"Volvo", "BMW", "Corola","Premio", "Alien", "Mercedes"};
	private JButton b1;
	
	Combo10()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("JComboBox");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		cb1=new JComboBox(cars);
		cb1.setBounds(20, 20, 70, 30);
		c.add(cb1);
		
		l1=new JLabel("Welcome");
		l1.setBounds(150, 20, 190, 50);
		c.add(l1);
		
		b1=new JButton("Select");
		b1.setBounds(20, 60, 70, 30);
		c.add(b1);
		
		b1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent ae)
			{
				String s=cb1.getSelectedItem().toString();
				l1.setText("You have selected "+s);
			}		
		});
		
		System.out.println("Total Items in the ComboBox= "+cb1.getItemCount());
	}
	
	public static void main(String args[])
	{
		Combo10 f1=new Combo10();
		f1.setVisible(true);
	}

}
