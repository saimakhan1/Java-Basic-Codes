package swing14_JComboBox;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Remove items from the comboBox specifying the index number
// removeItemAt() 

public class Combo7 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JComboBox cb1;
	private String [] cars= {"Volvo", "BMW", "Corola","Premio", "Alien", "Mercedes"};
	
	Combo7()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("JComboBox");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		cb1=new JComboBox(cars);
		cb1.setBounds(20, 20, 100, 50);
	
		cb1.removeItemAt(2);
		c.add(cb1);
		
		System.out.println("Total Items in the ComboBox= "+cb1.getItemCount());
	}
	
	public static void main(String args[])
	{
		Combo7 f1=new Combo7();
		f1.setVisible(true);
	}

}
