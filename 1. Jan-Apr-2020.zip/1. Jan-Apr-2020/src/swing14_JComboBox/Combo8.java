package swing14_JComboBox;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Remove all the items from the comboBox 
// removeAllItems() 

public class Combo8 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JComboBox cb1;
	private String [] cars= {"Volvo", "BMW", "Corola","Premio", "Alien", "Mercedes"};
	
	Combo8()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("JComboBox");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		cb1=new JComboBox(cars);
		cb1.setBounds(20, 20, 100, 50);
	
		cb1.removeAllItems();
		c.add(cb1);
		
		System.out.println("Total Items in the ComboBox= "+cb1.getItemCount());
	}
	
	public static void main(String args[])
	{
		Combo8 f1=new Combo8();
		f1.setVisible(true);
	}

}
