package swing14_JComboBox;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Adding Action Listener with Combo Box
// showing message in the dialog window

public class Combo9 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JComboBox cb1;
	private String [] cars= {"Volvo", "BMW", "Corola","Premio", "Alien", "Mercedes"};
	
	Combo9()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("JComboBox");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		cb1=new JComboBox(cars);
		cb1.setBounds(20, 20, 100, 50);
		c.add(cb1);
		
		l1=new JLabel("Welcome");
		l1.setBounds(150, 20, 190, 50);
		c.add(l1);
		
		cb1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent ae)
			{
				String s=cb1.getSelectedItem().toString();
				l1.setText("You have selected "+s);
			}
				
		});
		
		System.out.println("Total Items in the ComboBox= "+cb1.getItemCount());
	}
	
	public static void main(String args[])
	{
		Combo9 f1=new Combo9();
		f1.setVisible(true);
	}

}
