package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FocusListener1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JTextField tf1;
	private JTextArea ta0, ta1,ta2;
	private JScrollPane s0,s1,s2;
	private JButton b1, b2;
	
	FocusListener1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Mouse Listener");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.gray);
		
		b1=new JButton("Focus");
		b1.setBounds(20,20,70,30);
		c.add(b1);
		
		ta1=new JTextArea();
		ta1.setBounds(20, 60, 200, 150);
		ta1.setBackground(Color.LIGHT_GRAY);
		ta1.setLineWrap(true);
		ta1.setWrapStyleWord(true);
		c.add(ta1);
		
		
		b1.addFocusListener(new FocusListener() 
		{

			public void focusGained(FocusEvent fe) {
				
				ta1.setText("Focus Gained");
			}

			public void focusLost(FocusEvent fe) {
				ta1.setText("Focus Lost");
				
			}
			
		});
	}
	
	public static void main(String args[])
	{
		FocusListener1 f1=new FocusListener1();
		f1.setVisible(true);
	}

}
