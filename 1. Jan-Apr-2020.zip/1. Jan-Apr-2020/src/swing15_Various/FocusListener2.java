package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FocusListener2 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JTextField tf1;
	private JTextArea ta0, ta1,ta2;
	private JScrollPane s0,s1,s2;
	private JButton b1, b2, b0;
	
	FocusListener2()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 300,250);
		this.setTitle("Mouse Listener");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.gray);
		
		/*l1=new JLabel("Focus Listener");
		l1.setBounds(10, 0, 90, 30);
		c.add(l1);*/
		
		
		b0=new JButton("Test Focus");
		b0.setBounds(90,10,100,30);
		b0.setBackground(Color.pink);
		c.add(b0);
		
		b1=new JButton("Focus 1");
		b1.setBounds(20,40,90,30);
		c.add(b1);
		
		ta1=new JTextArea();
		ta1.setBounds(20, 80, 90, 90);
		ta1.setBackground(Color.LIGHT_GRAY);
		ta1.setLineWrap(true);
		ta1.setWrapStyleWord(true);
		c.add(ta1);
		
		b2=new JButton("Focus 2");
		b2.setBounds(170,40,90,30);
		c.add(b2);
		
		ta2=new JTextArea();
		ta2.setBounds(170, 80, 90, 90);
		ta2.setBackground(Color.LIGHT_GRAY);
		ta2.setLineWrap(true);
		ta2.setWrapStyleWord(true);
		c.add(ta2);
		
		
		b2.addFocusListener(new FocusListener() 
		{

			public void focusGained(FocusEvent fe) {
				
				ta2.setText("Focus Gained");
			}

			public void focusLost(FocusEvent fe) {
				ta2.setText("Focus Lost");
				
			}
			
		});
		
		b1.addFocusListener(new FocusListener() 
		{

			public void focusGained(FocusEvent fe) {
				
				ta1.setText("Focus Gained");
			}

			public void focusLost(FocusEvent fe) {
				ta1.setText("Focus Lost");
				
			}
			
		});
	}
	
	public static void main(String args[])
	{
		FocusListener2 f1=new FocusListener2();
		f1.setVisible(true);
	}

}
