package swing15_Various;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

// By default flow layout
public class JPanel1 extends JFrame{
	
	private Container c;
	private JLabel l1, l2, l3;
	private JPanel pn1, pn2;
	private JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, ba, bb, bc, bd, be; 
	
	JPanel1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 450,450);
		this.setTitle("JPanel");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		l1=new JLabel("Welcome to Jpanel");
		l1.setBounds(20, 20, 200, 50);
		c.add(l1);
		
		
		pn1=new JPanel();
		pn1.setBounds(20, 90, 150, 180);
		pn1.setBackground(Color.RED);
		c.add(pn1);
	
		pn2=new JPanel();
		pn2.setBounds(190, 90, 220, 180);
		pn2.setBackground(Color.green);
		c.add(pn2);
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		b6=new JButton("6");
		b7=new JButton("7");
		b8=new JButton("8");
		b9=new JButton("9");
		b0=new JButton("0");
		
		ba=new JButton("A");
		bb=new JButton("B");
		bc=new JButton("C");
		bd=new JButton("D");
		
		pn1.add(b1);
		pn1.add(b2);
		pn1.add(b3);
		pn1.add(b4);
		pn1.add(b5);
		pn1.add(b6);
		pn1.add(b7);
		pn1.add(b8);
		pn1.add(b9);
		pn1.add(b0);
		

		pn2.add(ba);
		pn2.add(bb);
		pn2.add(bc);
		pn2.add(bd);
	}
	
	public static void main(String args[])
	{
		JPanel1 f1=new JPanel1();
		f1.setVisible(true);
	}

}
