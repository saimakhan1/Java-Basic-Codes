package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class KeyListener1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JTextField tf1;
	private JTextArea ta1;
	
	KeyListener1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Key Listener");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		l1=new JLabel("KeyListener");
		l1.setBounds(20, 20, 100, 30);
		c.add(l1);
		
		tf1=new JTextField();
		tf1.setBounds(20, 50, 100, 30);
		c.add(tf1);
		
		ta1=new JTextArea();
		ta1.setBounds(20, 100, 200, 150);
		ta1.setBackground(Color.CYAN);
		c.add(ta1);
		
		tf1.addKeyListener(new KeyListener() {

			public void keyPressed(KeyEvent ke) {

				ta1.append("Key Pressed: "+ke.getKeyChar()+"\n");
			}	
			public void keyTyped(KeyEvent ke) {

				ta1.append("Key Typed: "+ke.getKeyChar()+"\n");
			}
			public void keyReleased(KeyEvent ke) {

				ta1.append("Key Realesd: "+ke.getKeyChar()+"\n");
			}	
		});
	}
	
	public static void main(String args[])
	{
		KeyListener1 f1=new KeyListener1();
		f1.setVisible(true);
	}

}
