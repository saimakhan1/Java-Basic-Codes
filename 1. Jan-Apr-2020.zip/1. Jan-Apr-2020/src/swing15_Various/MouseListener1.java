package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MouseListener1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JTextField tf1;
	private JTextArea ta0, ta1;
	private JScrollPane s0,s1,s2;
	
	MouseListener1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Mouse Listener");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.gray);
		
		l1=new JLabel("MouseListener");
		l1.setBounds(20, 20, 100, 30);
		c.add(l1);
		
		ta0=new JTextArea();
		ta0.setBounds(20, 50, 200, 50);
		ta0.setLineWrap(true);
		ta0.setWrapStyleWord(true);
		c.add(ta0);
		
		s0=new JScrollPane(ta0); 
		s0.setBounds(20,50,200,50);
		c.add(s0);
		
		ta1=new JTextArea();
		ta1.setBounds(20, 120, 200, 150);
		ta1.setBackground(Color.pink);
		ta1.setLineWrap(true);
		ta1.setWrapStyleWord(true);
		c.add(ta1);
		
		s1=new JScrollPane(ta1); 
		s1.setBounds(20,120,200,150);
		c.add(s1);
		
		ta0.addMouseListener(new MouseListener() 
		{
			public void mouseClicked(MouseEvent arg0) {
				ta1.append("Mouse Clicked\n");
			}
			public void mouseEntered(MouseEvent arg0) {
				ta1.append("Mouse Entered\n");	
			}
			public void mouseExited(MouseEvent arg0) {
				ta1.append("Mouse Exited\n");	
			}
			public void mousePressed(MouseEvent arg0) {
				ta1.append("Mouse Pressed\n");	
			}
			public void mouseReleased(MouseEvent arg0) {
				ta1.append("Mouse Released\n");	
			}
		});
	}
	
	public static void main(String args[])
	{
		MouseListener1 f1=new MouseListener1();
		f1.setVisible(true);
	}

}
