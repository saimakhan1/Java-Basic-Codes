package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MouseMotionListener1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JTextField tf1;
	private JTextArea ta0, ta1;
	private JScrollPane s0,s1,s2;
	
	MouseMotionListener1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Mouse Motion Listener");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.gray);
		
		l1=new JLabel("MouseMotionListener");
		l1.setBounds(20, 20, 130, 30);
		c.add(l1);
		
		ta0=new JTextArea();
		ta0.setBounds(20, 50, 200, 50);
		ta0.setLineWrap(true);
		ta0.setWrapStyleWord(true);
		c.add(ta0);
		
		
		ta1=new JTextArea();
		ta1.setBounds(20, 120, 200, 150);
		ta1.setBackground(Color.orange);
		c.add(ta1);
		
		
		ta0.addMouseMotionListener(new MouseMotionListener() 
		{
			public void mouseDragged(MouseEvent mme) {
				ta1.setText("Mouse Dragged. "+"(x,y)= "+mme.getX()+" "+mme.getY());
				
			}
			
			public void mouseMoved(MouseEvent mme) {
				ta1.setText("Mouse Moved. "+"(x,y)= "+mme.getX()+" "+mme.getY());
			}
			
		});
	}
	
	public static void main(String args[])
	{
		MouseMotionListener1 f1=new MouseMotionListener1();
		f1.setVisible(true);
	}

}
