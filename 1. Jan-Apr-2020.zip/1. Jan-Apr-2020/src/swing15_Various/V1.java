package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// 3rd way of adding action listener
// changing background color by clicking buttons

public class V1 extends JFrame implements ActionListener{
	
	private Container c;
	private JLabel l1;
	private JButton b1, b2, b3;
	
	V1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Colors");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		b1=new JButton("Red");
		b1.setBounds(20, 20, 80, 25);
		c.add(b1);
		

		b2=new JButton("Green");
		b2.setBounds(20, 50, 80, 25);
		c.add(b2);
		

		b3=new JButton("Blue");
		b3.setBounds(20, 80, 80, 25);
		c.add(b3);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent ae) {		
		if(ae.getSource()==b1)
		{
			c.setBackground(Color.RED);
		}
		else if(ae.getSource()==b2)
		{
			c.setBackground(Color.green);
		}
		else if(ae.getSource()==b3)
		{
			c.setBackground(Color.BLUE);
		}	
	}
	
	public static void main(String args[])
	{
		V1 f1=new V1();
		f1.setVisible(true);
	}

		

}
