package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class VowelCounter extends JFrame{
	
	private Container c;
	private JLabel l1,vLabel, al, el, il, ol, ul;
	private JTextArea ta1;
	private JScrollPane scroll1;
	int total_vowel=0, a=0,e=0,i=0,o=0,u=0;
	
	VowelCounter()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 380,380);
		this.setTitle("Vowel Counter");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		l1=new JLabel("Enter Text: ");
		l1.setBounds(20, 20, 100, 50);
		c.add(l1);
		
		ta1=new JTextArea();
		ta1.setLineWrap(true);
		ta1.setWrapStyleWord(true);
		ta1.setBounds(90, 20, 250, 50);
		c.add(ta1);
		
		scroll1=new JScrollPane(ta1);
		scroll1.setBounds(90,20,250,50);
		c.add(scroll1);
		
		vLabel=new JLabel("Vowels: ");
		vLabel.setBounds(110,70,250,30);
		c.add(vLabel);
		
		al=new JLabel("a");
		al.setBounds(110,90,250,30);
		c.add(al);
		
		el=new JLabel("e");
		el.setBounds(110,110,250,30);
		c.add(el);
		
		il=new JLabel("i");
		il.setBounds(110,130,250,30);
		c.add(il);
		
		ol=new JLabel("o");
		ol.setBounds(110,150,250,30);
		c.add(ol);
		
		ul=new JLabel("u");
		ul.setBounds(110,170,250,30);
		c.add(ul);
		
		ta1.addKeyListener(new KeyListener() {

			public void keyPressed(KeyEvent ke) {
				
				if(ke.getSource()==ta1)
				{
					if(ke.VK_A==ke.getKeyCode())
					{
						a++;
						total_vowel++;
					}
					else if(ke.VK_E==ke.getKeyCode())
					{
						e++;
						total_vowel++;
					}
					else if(ke.VK_I==ke.getKeyCode())
					{
						i++;
						total_vowel++;
					}
					else if(ke.VK_O==ke.getKeyCode())
					{
						o++;
						total_vowel++;
					}
					else if(ke.VK_U==ke.getKeyCode())
					{
						u++;
						total_vowel++;
					}
				}

				vLabel.setText("Total Number of Vowels: "+ total_vowel);
				al.setText("Total Number of a: "+ a);
				el.setText("Total Number of e: "+ e);
				il.setText("Total Number of i: "+ i);
				ol.setText("Total Number of o: "+ o);
				ul.setText("Total Number of u: "+ u);

			}	
			public void keyTyped(KeyEvent ke) {


			}
			public void keyReleased(KeyEvent ke) {

				
			}	
		});

	}
	
	public static void main(String args[])
	{
		VowelCounter f1=new VowelCounter();
		f1.setVisible(true);
	}

}
