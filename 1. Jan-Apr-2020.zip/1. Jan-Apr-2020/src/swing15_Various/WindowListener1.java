package swing15_Various;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class WindowListener1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	
	WindowListener1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Window Listener");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		l1=new JLabel("Window Listener");
		l1.setBounds(20, 20, 100, 50);
		c.add(l1);
		
		
		this.addWindowListener(new WindowListener() 
		{

			public void windowActivated(WindowEvent we) {
				System.out.println("Window Activated\n");
			}
  
			public void windowClosed(WindowEvent we) {
				System.out.println("Window Closed\n");
				
			}

			public void windowClosing(WindowEvent we) {
				System.out.println("Window Closing\n");
				
			}

			public void windowDeactivated(WindowEvent we) {
			
				System.out.println("Window Deactivated\n");
			}
			public void windowDeiconified(WindowEvent we) {
				System.out.println("Window Deiconified\n");
				
			}

			public void windowIconified(WindowEvent we) {
				System.out.println("Window Iconified\n");
				
			}

			public void windowOpened(WindowEvent we) {
				
				System.out.println("Window Opened\n");
			}
			
		});
	}
	
	public static void main(String args[])
	{
		WindowListener1 f1=new WindowListener1();
		f1.setVisible(true);
	}

}
