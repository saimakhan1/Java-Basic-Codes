package swing16_LayOut;
import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Border Layout 1, adding button without spaces

public class BorderLayout1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private BorderLayout border1;
	private JButton b1, b2, b3, b4, b5;
	
	BorderLayout1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Border Layout");
		
		c=this.getContentPane();
		
		c.setBackground(Color.LIGHT_GRAY);
		
		/*l1=new JLabel("Welcome to the new frame");
		l1.setBounds(20, 20, 200, 50);
		c.add(l1);*/
		
		border1=new BorderLayout();
		c.setLayout(border1);
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		
		c.add(b1, BorderLayout.NORTH);
		c.add(b2, BorderLayout.WEST);
		c.add(b3, BorderLayout.CENTER);
		c.add(b4, BorderLayout.EAST);
		c.add(b5, BorderLayout.SOUTH);
		
	}
	
	public static void main(String args[])
	{
		BorderLayout1 f1=new BorderLayout1();
		f1.setVisible(true);
	}

}
