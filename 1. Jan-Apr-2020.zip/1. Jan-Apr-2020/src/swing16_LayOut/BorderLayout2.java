package swing16_LayOut;
import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Border Layout 1, adding button with horizontal and vertical spaces

public class BorderLayout2 extends JFrame{
	
	private Container c;
	private BorderLayout border1;
	private JButton b1, b2, b3, b4, b5;
	
	BorderLayout2()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Border Layout 2");
		
		c=this.getContentPane();
		
		c.setBackground(Color.LIGHT_GRAY);
		
		border1=new BorderLayout();
		border1.setHgap(5);
		border1.setVgap(15);
		c.setLayout(border1);
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		
		c.add(b1, BorderLayout.NORTH);
		c.add(b2, BorderLayout.WEST);
		c.add(b3, BorderLayout.CENTER);
		c.add(b4, BorderLayout.EAST);
		c.add(b5, BorderLayout.SOUTH);
		
	}
	
	public static void main(String args[])
	{
		BorderLayout2 f1=new BorderLayout2();
		f1.setVisible(true);
	}

}
