package swing16_LayOut;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// CardLayout 1

public class CardLayout1 extends JFrame implements ActionListener{
	
	private Container c;
	private JLabel l1;
	private CardLayout card1;
	private JButton b1, b2, b3, b4, b5;
	
	CardLayout1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Card Layout");
		
		c=this.getContentPane();
		
		c.setBackground(Color.LIGHT_GRAY);
		
		card1=new CardLayout();    
		c.setLayout(card1);
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);

		
		c.add(b1);
		c.add(b2);
		c.add(b3);
		c.add(b4);
		
		
	}
	
	public static void main(String args[])
	{
		CardLayout1 f1=new CardLayout1();
		f1.setVisible(true);
	}

	
	public void actionPerformed(ActionEvent arg0) {
		card1.next(c); // automatically next options will be appear after clicking the options 

		//card1.previous(c); 
		
	}

		
}
