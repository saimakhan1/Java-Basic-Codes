package swing16_LayOut;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// CardLayout 4, specify what will come next (2)

public class CardLayout4 extends JFrame implements ActionListener{
	
	private Container c;
	private JLabel l1;
	private CardLayout card1;
	private JButton b1, b2, b3, b4, b5;
	
	CardLayout4()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Card Layout");
		
		c=this.getContentPane();
		
		c.setBackground(Color.LIGHT_GRAY);
		
		card1=new CardLayout();    
		c.setLayout(card1);
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
	
		c.add(b1, "One");
		c.add(b2, "Two");
		c.add(b3, "Three");
		c.add(b4, "Four");
		c.add(b5, "Five");
	
	}
	
	public static void main(String args[])
	{
		CardLayout4 f1=new CardLayout4();
		f1.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent arg0) {
		card1.last(c);
		//card1.first(c);
	}

		
}
