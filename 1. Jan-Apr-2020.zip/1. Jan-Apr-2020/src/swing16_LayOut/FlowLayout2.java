package swing16_LayOut;
import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Flow Layout 2, customized alignment, left alignment, right alignment  

public class FlowLayout2 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private FlowLayout flow1;
	private JButton b[];
	
	FlowLayout2()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Flow Layout");
		
		c=this.getContentPane();
		c.setBackground(Color.LIGHT_GRAY);
		
		
		//flow1=new FlowLayout(FlowLayout.LEFT);
		flow1=new FlowLayout(FlowLayout.RIGHT);

		c.setLayout(flow1);
		
		b=new JButton[10];
		
		for(int i=0;i<10;i++)
		{
			b[i]=new JButton(""+i);
			c.add(b[i]);
		}
		
			
	}
	
	public static void main(String args[])
	{
		FlowLayout2 f1=new FlowLayout2();
		f1.setVisible(true);
	}

}
