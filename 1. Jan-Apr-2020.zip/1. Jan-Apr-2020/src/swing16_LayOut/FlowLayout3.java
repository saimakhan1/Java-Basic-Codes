package swing16_LayOut;
import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Flow Layout 3, specify horizontal and vertical gap  

public class FlowLayout3 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private FlowLayout flow1;
	private JButton b[];
	
	FlowLayout3()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Flow Layout");
		
		c=this.getContentPane();
		c.setBackground(Color.LIGHT_GRAY);
		
		
		flow1=new FlowLayout(FlowLayout.LEFT);
		flow1.setHgap(35);
		flow1.setVgap(15);
		
		//flow1=new FlowLayout(FlowLayout.RIGHT);

		c.setLayout(flow1);
		
		b=new JButton[10];
		
		for(int i=0;i<10;i++)
		{
			b[i]=new JButton(""+i);
			c.add(b[i]);
		}
		
			
	}
	
	public static void main(String args[])
	{
		FlowLayout3 f1=new FlowLayout3();
		f1.setVisible(true);
	}

}
