package swing16_LayOut;
import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

// GridLayout 1, default layout in grid layout, columns

public class GridLayout1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private GridLayout grid1;
	private JButton b1, b2, b3, b4, b5;
	
	GridLayout1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Grid Layout");
		
		c=this.getContentPane();
		
		c.setBackground(Color.LIGHT_GRAY);
		
		grid1=new GridLayout();
		c.setLayout(grid1);
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		
		c.add(b1);
		c.add(b2);
		c.add(b3);
		c.add(b4);
		c.add(b5);
		
	}
	
	public static void main(String args[])
	{
		GridLayout1 f1=new GridLayout1();
		f1.setVisible(true);
	}

}
