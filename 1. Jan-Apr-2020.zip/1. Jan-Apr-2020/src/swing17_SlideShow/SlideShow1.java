package swing17_SlideShow;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SlideShow1 extends JFrame{
	
	private Container c;
	private JLabel l1;
	private JPanel pn1;
	private JButton prevButton, nextButton;
	
	SlideShow1()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Slide Show");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		pn1=new JPanel();
		pn1.setBounds(20, 20, 300, 250);
		pn1.setBackground(Color.CYAN);
		c.add(pn1);
		
		prevButton=new JButton("Previous");
		prevButton.setBounds(10,280,90,20);
		c.add(prevButton);
		
		nextButton=new JButton("Next");
		nextButton.setBounds(210,280,90,20);
		c.add(nextButton);
		
		
		/*pn1.add(prevButton);
		pn1.add(nextButton);*/
		
		
	}
	
	public static void main(String args[])
	{
		SlideShow1 f1=new SlideShow1();
		f1.setVisible(true);
	}

}
