package swing2_showInputDialog;
import javax.swing.JOptionPane;

public class InputDialog1 {
	
	public static void main(String args[])
	{
		
		
		String Name=JOptionPane.showInputDialog("Enter Your Name: ");
		
		JOptionPane.showMessageDialog(null, Name + " Congratulation, Your Name has been added");
		
	}
	
	

}
