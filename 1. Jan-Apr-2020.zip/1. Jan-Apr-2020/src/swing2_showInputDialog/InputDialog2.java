package swing2_showInputDialog;

import javax.swing.JOptionPane;

public class InputDialog2 {
	
	public static void main(String args[])
	{
		String name1=JOptionPane.showInputDialog("Enter your First name: ", "John ");
		
		String name2=JOptionPane.showInputDialog(null,"Enter your Last name:", "Title: name2", JOptionPane.QUESTION_MESSAGE);
		
		String full_name=name1+name2;
		
		JOptionPane.showMessageDialog(null, "Your Full Name is: "+ full_name);
	}

}
