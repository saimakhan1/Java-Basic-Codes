package swing3_showConfirmDialog;

import javax.swing.JOptionPane;

public class ConfirmDialog1 {
	
	public static void main(String args[])
	{
		JOptionPane.showConfirmDialog(null, "Do you want to Continue?","Title: Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
	}

}
