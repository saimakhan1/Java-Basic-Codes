package swing3_showConfirmDialog;

import javax.swing.JOptionPane;

public class ConfirmDialog2 {
	
	public static void main(String args[])
	{
		int option=JOptionPane.showConfirmDialog(null, "Do you want to Continue?",
				"Title: Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
		
		if(option==JOptionPane.YES_OPTION)
		{
			System.exit(0);
		}
		else if(option==JOptionPane.NO_OPTION)
		{
			System.out.print("You Are in Previous Page Now!");
		}
		
		else
		{
			System.out.print("You Are at Current Page!");
		}
	}

}
