package swing4_showOptionDialog;
import javax.swing.JOptionPane;

public class Option1
{
	public static void main(String args[])
	{
		int choice=JOptionPane.showOptionDialog(null, "Do you want to quit?", "Quit",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,
				null, null, null);
		
		  if (choice == JOptionPane.YES_OPTION)
		  {
		    System.exit(0);
		  } 
		  else
		  {
			  System.out.print("You Chose the No Options!");
		  }	
	}
}
