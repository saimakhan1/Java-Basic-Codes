package swing6_ActionListener;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel
import javax.swing.JOptionPane;

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;

import java.awt.event.ActionEvent;//to work with action listener
import java.awt.event.ActionListener;//to work with action listener

public class Frame5a extends JFrame{
	
	private JLabel imageLabel;
	private Container c;
	private JTextField t1,t2,t3;
	
	Frame5a()
	{
		Methods();
	}
	
public void Methods()
	{
		c= this.getContentPane();//bring the container here
		c.setLayout(null);
		
		t1=new JTextField("Hello Textfield!");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
	t1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String s1= t1.getText();
				if(s1.isEmpty())
				{
					JOptionPane.showMessageDialog(null,"Empty Content");
				}
				else 
				{
					JOptionPane.showMessageDialog(null, " "+s1);
				}
			}
		}
	);
	} 

	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame5a frame=new Frame5a();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Single ActionListener");
		
	}

}
