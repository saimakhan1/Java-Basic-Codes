package swing6_ActionListener;

//create JTextField
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel
import javax.swing.JOptionPane;

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;

import java.awt.event.ActionEvent;//to work with action listener
import java.awt.event.ActionListener;//to work with action listener


public class Frame6a extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JTextField t1,t2,t3;
	
	Frame6a()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.black);
		
		t1=new JTextField("Hello Textfield!");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
		t2=new JTextField();
		t2.setBounds(50,100,100,30);
		c.add(t2);
		
		t3=new JTextField();
		t3.setBounds(50,150,200,30);
		c.add(t3);
		
		multi_action a1=new multi_action();//for handling multiple action listener
				
		t1.addActionListener(a1);
		t2.addActionListener(a1);
		
	}
	
	class multi_action implements ActionListener{
		public void actionPerformed(ActionEvent e)
		{
			if(e.getSource()==t1)
			{
				String s1=t1.getText();
				
				if(s1.isEmpty())
				{
					JOptionPane.showMessageDialog(null,"Please Enter something! s1");
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "string1: "+s1);
				}
			}
		
			
			else if(e.getSource()==t2)
			{
				String s2=t2.getText();
				
				if(s2.isEmpty())
				{
					JOptionPane.showMessageDialog(null,"Please Enter something s2!");
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "string2: "+s2);
				}
			}

				
		}
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame6a frame=new Frame6a();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Multiple Action Listener");
		
	}

	
}
