package swing6_ActionListener;

//create JTextField
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;//used for JPasswordField

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;


import java.awt.Font;


public class Frame6b extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JTextField t1,t2,t3;
	private JPasswordField p1;
	private JLabel l1;
	private Font f1;
	
	Frame6b()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.black);
		
		f1=new Font("Arial",Font.ITALIC,20);
		
		t1=new JTextField("Hello Textfield!");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
		t2=new JTextField();
		t2.setBounds(50,100,100,30);
		c.add(t2);
		
		t3=new JTextField();
		t3.setBounds(50,150,200,30);
		c.add(t3);
		
		l1=new JLabel();
		l1.setText("Enter Your Password: ");
		l1.setForeground(Color.white);
		l1.setBounds(50,200,200,30);
		c.add(l1);
		
		p1=new JPasswordField();
		p1.setEchoChar('*');//define the word or character which you want to see as password
		p1.setBounds(50,230,100,30);
		p1.setFont(f1);
		p1.setForeground(Color.green);
		p1.setBackground(Color.RED);
		c.add(p1);
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		Frame6b frame=new Frame6b();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Title: JPasswordField");		
	}

}
