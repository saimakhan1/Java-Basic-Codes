package swing7_JButton;

//create JBUtton
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel
import javax.swing.JOptionPane;

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import java.awt.Font;

public class button1 extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JTextField t1,t2,t3;
	
	private JButton b1,b2,b3;
	private Font f1;
	
	button1()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.black);
		
		t1=new JTextField("Hello Textfield!");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
		f1=new Font("Arial",Font.ITALIC,10);
		
		b1=new JButton("Hello Button!");
		b1.setBounds(50,100,110,30);
		b1.setFont(f1);
		c.add(b1);
		
		b2=new JButton("Hello Bangladesh!");
		b2.setBounds(190,100,140,30);
		b2.setForeground(Color.red);
		b2.setBackground(Color.green);
		c.add(b2);
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		button1 frame=new button1();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Title:Create JButton");
		
	}

	
}
