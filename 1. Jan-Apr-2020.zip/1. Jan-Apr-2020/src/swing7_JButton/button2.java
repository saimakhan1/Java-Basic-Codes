package swing7_JButton;

//create JBUtton
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel
import javax.swing.JOptionPane;

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import java.awt.Font;

import java.awt.Cursor;
import javax.swing.ImageIcon;

public class button2 extends JFrame{
	
	private JLabel imageLabel;
	
	private Container c;
	private JTextField t1,t2,t3;
	
	private JButton b1,b2,b3,b4;
	private Font f1;
	
	private Cursor cursor1;
	private ImageIcon img1,img2,img3,img4;
	
	button2()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		//
		//this.setIconImage(icon.getImage());//icon set
		
		img1=new ImageIcon(getClass().getResource("pic1.jpg"));
		img2=new ImageIcon(getClass().getResource("pic2.jpg"));
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.black);
		
		t1=new JTextField("Hello Textfield!");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
		f1=new Font("Arial",Font.ITALIC,10);
		cursor1=new Cursor(Cursor.HAND_CURSOR);
		
		b1=new JButton("Hello Button!");
		b1.setBounds(50,100,110,30);
		b1.setFont(f1);
		c.add(b1);
		
		b2=new JButton("Button 2!");
		b2.setBounds(200,100,110,30);
		b2.setForeground(Color.red);
		b2.setBackground(Color.green);
		b2.setCursor(cursor1);
		c.add(b2);
		
		b3=new JButton(img1);
		b3.setBounds(50,150,110,30);
		b3.setFont(f1);
		c.add(b3);
		
		b4=new JButton(img2);
		b4.setBounds(200,150,110,30);
		b4.setFont(f1);
		c.add(b4);
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		button2 frame=new button2();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Title:Create JButton");
		
	}

	
}
