package swing7_JButton;

//create JTextField
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel
import javax.swing.JOptionPane;
import javax.swing.JButton;

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;

import java.awt.event.ActionEvent;//to work with action listener
import java.awt.event.ActionListener;//to work with action listener


public class button4 extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JTextField t1,t2,t3;
	private JButton b1,b2,b3;
	
	button4()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.DARK_GRAY);
		
		t1=new JTextField("Hello");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
		b1=new JButton("Clear");
		b1.setBounds(200,50,100,30);
		c.add(b1);
		
		b1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				t1.setText("");
			}
		});
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		button4 frame=new button4();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Title:JButton with ActionListener");
		
	}

	
}
