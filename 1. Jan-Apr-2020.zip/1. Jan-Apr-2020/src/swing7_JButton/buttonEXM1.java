package swing7_JButton;

//create JTextField
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;//for creating JLabel
import javax.swing.JOptionPane;
import javax.swing.JButton;

import java.awt.Font;// to create font
import java.awt.Color;
import java.awt.Container;

import java.awt.event.ActionEvent;//to work with action listener
import java.awt.event.ActionListener;//to work with action listener

public class buttonEXM1 extends JFrame{
	
	private ImageIcon icon,icon2;//add a variable of ImageIcon
	private JLabel imageLabel;
	
	private Container c;
	private JLabel l1,l2,l3;
	private JTextField t1,t2,t3;
	private JButton b1,b2,b3;
	
	buttonEXM1()
	
	{
		keep_methods();
	}
	
	public void keep_methods()
	{
		icon=new ImageIcon(getClass().getResource("vlc.PNG"));//icon set
		this.setIconImage(icon.getImage());//icon set
		
		c= this.getContentPane();//bring the container here
		
		c.setLayout(null);
		c.setBackground(Color.gray);
		
		l1=new JLabel("Name: ");
		l1.setBounds(10,40,50,50);
		c.add(l1);
		
		t1=new JTextField("John");
		t1.setBounds(50,50,100,30);
		c.add(t1);
		
		b1=new JButton("Clear");
		b1.setBounds(200,50,100,30);
		c.add(b1);
		
		l2=new JLabel("ID: ");
		l2.setBounds(10,80,50,50);
		c.add(l2);
		
		t2=new JTextField("011201");
		t2.setBounds(50,100,100,30);
		c.add(t2);
		
		b2=new JButton("Clear");
		b2.setBounds(200,100,100,30);
		c.add(b2);
		
		b3=new JButton("Submit");
		b3.setBounds(80,200,200,30);
		c.add(b3);
		
		b1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				t1.setText("");
			}
		});
		
	}
	
	public static void main(String args[])
	{
		//codes written here will be unchanged all the time to create a frame
		buttonEXM1 frame=new buttonEXM1();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("Submit Window");
		
	}

	
}
