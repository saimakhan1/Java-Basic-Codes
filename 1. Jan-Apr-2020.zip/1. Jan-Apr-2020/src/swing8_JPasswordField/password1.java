package swing8_JPasswordField;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JPasswordField; 

public class password1 extends JFrame{
	private Container c;
	private JPasswordField p1; 
	
	password1()
	{
		components();
	}
	
	public void components()
	{
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.DARK_GRAY);
		
		p1=new JPasswordField();
		p1.setEchoChar('*');
		p1.setBounds(60, 40, 150, 60);
		c.add(p1);
	}
	
	public static void main(String args[])
	{
		password1 frame=new password1();
		frame.setVisible(true);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(50,100,400,500);
		frame.setTitle("PasswordField");
		
	}

}
