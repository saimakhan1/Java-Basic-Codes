package swing9_LogInFrame;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Frame_c2 extends JFrame{
	
	private Container c;
	private JLabel l1;
	
	Frame_c2()
	{
		components();
	}
	
	public void components()
	{
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500, 150, 350,350);
		this.setTitle("Fram_c2");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.LIGHT_GRAY);
		
		l1=new JLabel("Hello! \nYou are Signed In");
		l1.setBounds(20, 20, 150, 50);
		c.add(l1);
	}
	
	public static void main(String args[])
	{
		Frame_c2 f1=new Frame_c2();
		f1.setVisible(true);
	}

}
