package swing9_LogInFrame;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton; 
import javax.swing.JPasswordField;
// Create a new frame from existing frame
// when we close the 2nd frame, the 1st frame is also closed here with the 2nd frame
public class loginframe3 extends JFrame{
	private JLabel userLabel, passwordLabel;
	private JTextField t1; 
	private JButton submitB, clearB;
	private JPasswordField p1; 
	private Container c;
	private Font f1;
	loginframe3()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(150, 150, 350,350);
		this.setTitle("Log In Frame");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.pink);
		f1=new Font("Arial",Font.BOLD,16);
		
		userLabel= new JLabel("Username: ");
		userLabel.setBounds(30, 50, 150, 20);
		userLabel.setFont(f1);
		c.add(userLabel);
		
		t1=new JTextField();
		//t1.setFont(f1);
		t1.setBounds(130,50,150,25);
		c.add(t1);
		
		passwordLabel= new JLabel("Password: ");
		passwordLabel.setBounds(30, 90, 150, 20);
		passwordLabel.setFont(f1);
		c.add(passwordLabel);
		
		p1=new JPasswordField();
		//t1.setFont(f1);
		p1.setBounds(130,90,150,25);
		c.add(p1);
		
		submitB=new JButton("Log In");
		submitB.setBounds(130, 140, 70, 40);
		//submitB.setFont(f1);
		c.add(submitB);
		
		clearB=new JButton("Clear");
		clearB.setBounds(210, 140, 70, 40);
		//submitB.setFont(f1);
		c.add(clearB);
		
		clearB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				t1.setText(" ");
				p1.setText("");
				}
		}
		);
		
		submitB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				
				String username= t1.getText();
				String password=p1.getText();
				
				if(username.equals("Saima") && password.equals("123"))
				{
					JOptionPane.showMessageDialog(null, "Log In successful");
					Frame_c fr1=new Frame_c();
					fr1.setVisible(true);
				}
				else
					JOptionPane.showMessageDialog(null, "Invalid Username of password");
				}
			
		}
		);
	}
	
	public static void main(String args[])
	{
		loginframe3 f1=new loginframe3();
		f1.setVisible(true);
	}

}
