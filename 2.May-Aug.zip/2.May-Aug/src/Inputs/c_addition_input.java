package Inputs;
import java.util.Scanner; // import the Scanner class to take input

public class c_addition_input {
	
	public static void main(String args[])
	{
		int a,b,sum;
		
	    Scanner input1 = new Scanner(System.in);
	    a = input1.nextInt(); // to take integer input, use nextInt
	    
	    Scanner input2 = new Scanner(System.in);
	    b = input2.nextInt(); 
	    
		sum=a+b;
		
		System.out.println("sum= "+sum);
		
		/*this
		 * will
		 * print sum*/
	}

}
