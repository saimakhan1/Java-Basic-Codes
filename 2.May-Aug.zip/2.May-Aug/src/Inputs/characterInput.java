package Inputs;
import java.util.Scanner;

public class characterInput {
	
	public static void main(String args[])
	{
		  // Create a Scanner object for reading input from the console
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a character
        System.out.println("Enter a character: ");
        char input = scanner.next().charAt(0);

        // Print the entered character
        System.out.println("You entered: " + input);

        // Close the scanner
        scanner.close();
    }
}


