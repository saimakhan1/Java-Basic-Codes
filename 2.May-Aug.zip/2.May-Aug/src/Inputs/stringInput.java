package Inputs;
import java.util.Scanner;

public class stringInput {

		public static void main(String args[])
		{
			
			  // Create a Scanner object for reading input from the console
	        Scanner s1= new Scanner(System.in);

	        // Prompt the user to enter a string
	        System.out.println("Enter a string: ");
	        String input1 = s1.nextLine();

	        // Reverse the string
	        String reversedString = new StringBuilder(input1).reverse().toString();

	        // Print the reversed string
	        System.out.println("Reversed string: " + reversedString);

	        // Close the scanner
	        s1.close();

		}
}
