package Inputs;
import java.util.Scanner;// This library is needed for using scanner class

public class stringInputPrint {
	
	public static void main(String[] args) {
        // Create a Scanner object for reading input from the console
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a string
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        // Print the entered string
        System.out.println("You entered: " + input);

        // Close the scanner
        scanner.close();

	}
}
