package Inputs;
import java.util.Scanner;

public class sumFloats {
    public static void main(String[] args) {
        // Create a Scanner object for reading input from the console
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the first float number
        System.out.println("Enter the first float number: ");
        float number1 = scanner.nextFloat();

        // Prompt the user to enter the second float number
        System.out.println("Enter the second float number: ");
        float number2 = scanner.nextFloat();

        // Calculate the sum of the two float numbers
        float sum = number1 + number2;

        // Print the sum
        System.out.println("The sum of the two numbers is: " + sum);

        // Close the scanner
        scanner.close();
    }
}