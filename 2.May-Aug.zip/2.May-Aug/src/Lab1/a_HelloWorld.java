package Lab1;

public class a_HelloWorld {
	public static void main(String arga[])
	{
		System.out.println("Hello World!");
	}
	
}
