package Lab1;

public class b_add {
	public static void main(String args[])
	{
		int a=5, b=10,sum;
		sum=a+b;
		System.out.println("Sum= "+sum);
		System.out.print("Sum= "+sum);
		System.out.println("Sum= "+sum);
		System.out.print("Sum= "+sum+" ");
		System.out.print("Sum= "+sum+ " Hello World!");
	}

}
