package Lab2;

public class Max {
	
	public static void main(String args[])
	{
		int a[]= {3,4,5,1,12};
		int max=a[0];
		for(int i=0;i<a.length;i++)
		{
			if (a[i]>max)
				max=a[i];
		}
		System.out.println("Largest number is: "+max);
	}
}
