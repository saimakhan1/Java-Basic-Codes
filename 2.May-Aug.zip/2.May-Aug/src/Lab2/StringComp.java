package Lab2;

public class StringComp {
	   public static void main(String[] args)
	    {
	        String s1 = "Hello World";
	        String s2 = "Hello Bangladesh";
	        String s3 = "Hello World";

	        // Are any of the above Strings equal to one another?
	        boolean equals1 = s1.equals(s2);
	        boolean equals2 = s1.equals(s3);

	        // Display the results of the equality checks.
	        System.out.println("\"" + s1 + "\" equals \"" +
	            s2 + "\"? " + equals1);
	        System.out.println("\"" + s1 + "\" equals \"" +
	            s3 + "\"? " + equals2);
	    }
	}



