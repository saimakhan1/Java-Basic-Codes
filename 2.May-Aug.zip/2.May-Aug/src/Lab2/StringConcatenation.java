package Lab2;

public class StringConcatenation {
	
	public static void main(String args[])
	{
		String s1="play", s2=" and", s3=" cricket"+".";
		System.out.println("I "+s1+" football "+s2+s3);
		
		int len=s1.length();
		System.out.println("Length of s1 is: "+len);

	}

}
