package Lab2;

import java.util.Scanner;  
public class average {  
   public static void main(String[] args)  
    {  
      int n, count = 1;   
      float  x, average, sum = 0;   
      Scanner s = new Scanner(System.in);     
      System.out.println("Enter the value of n");  
      n = s.nextInt();  
      while (count <= n)   
             {   
                  System.out.println("Enter the "+count+" number?");  
                  x = s.nextInt();  
                  sum += x;   
                  ++count;   
             }   
                  average = sum/n;   
        System.out.println("The Average is "+average);  
    }    
}  