package Lab2;

public class squareRoot {
	
	public static void main(String args[])
	{
		double x=5, y;
		y = Math.sqrt(x);
		System.out.println("y= "+y);
		System. out. format("y= %.3f\n", y);
		System. out. println("y= " + String. format("%.2f", y));
	}
}
