package Lab3;

class Apple
{
	String color()
	{
		return "red";
	}
	
	String taste()
	{
		return "sweet";
	}
	int weight()
	{
		return 15;
	}
}

class Mango{
	
	String color()
	{
		return "Yellow";
	}
	
	String taste()
	{
		return "sweet";
	}
	int weight()
	{
		return 12;
	}
	
}

class Grape{
	
	String color()
	{
		return "Purple";
	}
	
	String taste()
	{
		return "sour and sweet";
	}
	int weight()
	{
		return 5;
	}
	
}



public class Fruits {
	public static void main(String args[])
	{
		Apple a1=new Apple();
		Mango m1=new Mango();
		Grape g1=new Grape();
		
		System.out.println("The color of Apple is "+a1.color()+"\nThe color of Mango is"
				+ " "+ m1.color());
		System.out.print("The taste of grape is "+g1.taste());
	}
	
}
