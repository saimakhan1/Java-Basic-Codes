package Lab3;

class Banana{
	
	String color()
	{
		return "Yellow";
	}
	
	String taste()
	{
		return "sweet";
	}
	int weight()
	{
		return 9;
	}
	
}

public class Fruits1 {
	
	public static void main(String args[])
	{
		Banana b1=new Banana();
		
		System.out.println("The color of banana is "+b1.color());
		System.out.print("The taste of banana is "+b1.taste());
	}
	

}
