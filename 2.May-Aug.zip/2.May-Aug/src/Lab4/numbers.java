package Lab4;

public class numbers {
	int x=5,y=6;
}
class addition extends numbers{
	
	int add()
	{	
		return x+y;
	}	
}
class multiplication extends numbers{
	int product()
	{
		return x*y;
	}
}