package Lab4;

public class testNumbers {
	public static void main(String args[])
	{
		addition a1=new addition();
		multiplication m1=new multiplication();
		
		System.out.println("Summation is: "+a1.add());
		
		System.out.println("Product is: "+m1.product());
		
	}

}
