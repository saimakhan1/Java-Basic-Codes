package Lab5;

public class Account {
	
	String id,name;
	int balance;
	
	Account()
	{
		
	}
	
	Account(String id, String name)
	{
		this.id=id;
		this.name=name;
	}
	Account(String id, String name, int balance)
	{
		this.id=id;
		this.name=name;
		this.balance=balance;
	}

	String getId()
	{
		return id;
	}
	String getName()
	{
		return name; 
	}
	
	int getBalance()
	{
		return balance;
	}
	
	int credit(int amount)
	{
			balance=balance+amount;
			
		return balance;
	}
	
	int debit(int amount)
	{
		if(amount<=balance)
			balance=balance-amount;
		else 
			System.out.println("Amout exceeded balance");
		
		
		return balance;
	}
	int TransferTo(Account another, int amount)
	{
		if(amount<=balance)
			balance=balance-amount;
		else 
			System.out.println("Amout exceeded balance");
		
		
		return balance;
	}
	
	public String toString(){//overriding the toString() method  
		  return id+" "+name+" "+balance; 
	}

}
