package Lab5;

public class Account2 extends Account{
	
	void Account2()
	{
		
	}

}
