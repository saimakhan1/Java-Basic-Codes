package Lab5;

public abstract class Animal {

	abstract void sound();
	abstract void food();
	abstract void tail();
	abstract void lifespan();
	
}
