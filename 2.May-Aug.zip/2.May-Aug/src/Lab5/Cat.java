package Lab5;

public class Cat extends Animal{
	/*you have to implement all the abstract methods 
	 * of the abstract class that has been extended 
	*/
	
	void sound()
	{
		System.out.println("Cat sound: mew");
	}
	
	void food()
	{
		System.out.println("Cat Food: Fish Bone");
	}
	
	void tail()
	{
		System.out.println("Cat Tails: straight");
	}
	void lifespan()
	{
		System.out.println("Cat LifeSpan: 15 years");
	}



}
