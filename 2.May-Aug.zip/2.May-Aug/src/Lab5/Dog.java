package Lab5;

public class Dog extends Animal{
	/*you have to implement all the abstract methods 
	 * of the abstract class that has been extended 
	*/
	
	void sound()
	{
		System.out.println("Dog sound: woof");
	}
	
	void food()
	{
		System.out.println("Dog Food: Fish Bone, Chicken Bone");
	}
	
	void tail()
	{
		System.out.println("Dog Tails: curled, sickle, cock-screw");
	}
	void lifespan()
	{
		System.out.println("Dog LifeSpan: 2.5 years");
	}

}
