package Lab5;

public class testAccount {
	public static void main(String args[])
	{
		Account a1=new Account("A01","tani");
		Account a2=new Account("A02","Rini",10000);
		
		System.out.println(a1.getId());
		
		System.out.println(a1);
		System.out.println(a2);
		
		
		a2.getBalance();
		System.out.println("Balance after increment (credit) is: "+ a2.credit(800));
		
		
		System.out.println("Balance after decrement (debit) is: "+ a2.debit(300));
		
	}

}
