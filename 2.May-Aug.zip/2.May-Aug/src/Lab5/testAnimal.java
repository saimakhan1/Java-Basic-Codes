package Lab5;

public class testAnimal {
	
	public static void main(String arga[])
	{
		Dog d1=new Dog();
		Cat c1=new Cat();
		d1.food();
		d1.tail();
		d1.lifespan();
		d1.sound();
	
		c1.food();
		c1.tail();
		c1.lifespan();
		c1.sound();
	}

}
