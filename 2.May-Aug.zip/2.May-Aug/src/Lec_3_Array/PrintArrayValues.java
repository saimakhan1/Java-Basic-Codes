package Lec_3_Array;

public class PrintArrayValues {
	public static void main(String args[])
	{
		int []a=new int [5];
		a[0]=100; 
		a[1]=30;
		a[4]=20;
		int i;
		for(i=0;i<a.length;i++)
			System.out.println( a[ i ] );
	}
	
}





