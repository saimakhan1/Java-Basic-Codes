package Lec_3_Array;
import java.util.Arrays;
import java.util.Scanner;

public class read_input {
   public static void main(String args[]) {
      Scanner s1 = new Scanner(System.in);
      System.out.println("Enter the length of the array:");
      int length = s1.nextInt();
      int [] a1 = new int[length];
      System.out.println("Enter the elements of the array:");

      for(int i=0; i<length; i++ ) {
         a1[i] = s1.nextInt();
      }

      System.out.println(Arrays.toString(a1));
   }
}