package Lec_4_inheritance1;

public class bus extends vehicle{
	
	void color()
	{
		System.out.println("Color of bus is Red");
	}
	void size()
	{
		System.out.println("Bus is big");
	}
	void speed()
	{
		System.out.print("Speed of bus is 40 km/h");
	}


}
