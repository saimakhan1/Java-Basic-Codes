package Lec_4_inheritance1;

public class car extends vehicle{

	
	void color()
	{
		System.out.println(" car color: green");
	}
	void size()
	{
		System.out.println("car size: Small");
	}
	void speed()
	{
		System.out.println("car speed: 50 km/h");
	}

}
