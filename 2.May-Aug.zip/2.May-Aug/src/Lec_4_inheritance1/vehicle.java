package Lec_4_inheritance1;

public class vehicle {
	
	void Engine()
	{
		System.out.println("\nEngine model is LIBERTY CLASSICS 1:6");
	}
	
	void color()
	{
		System.out.println("vehicle color: White");
		
	}
	
	void size()
	{
		System.out.print("Regular");
	}
	void speed()
	{
		System.out.print("10 km/h");
	}
}
