package Lec_4_inheritance1;

public class vehicleDemo {
	public static void main(String args[])
	{
		vehicle v1=new vehicle();
		bus b1=new bus();
		car c1=new car();
		v1.Engine();
		v1.color();
		c1.Engine();
		c1.color();
		b1.color();
		b1.speed();
		b1.Engine();
		
	}

}
