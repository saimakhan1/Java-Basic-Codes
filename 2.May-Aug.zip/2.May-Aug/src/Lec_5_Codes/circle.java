package Lec_5_Codes;

public class circle {
	double radius;
	circle()
	{
		radius=1;
		System.out.println("Hello");
	}
	circle(double radius)
	{
		this.radius=radius;
	}
	double getRadius()
	{
		return radius;
	}

	double getArea()
	{
		return radius*radius*Math.PI;
	}
}
