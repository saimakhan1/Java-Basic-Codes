package Lec_5_Codes;

public class cylinder extends circle{
	double height;
	cylinder()
	{
		super();
		height=1;
	}
	cylinder(double height)
	{
		super();
		//super(radius);
		this.height=height;
	}
	cylinder(double radius, double height)
	{
		//super();
		///super (radius);
		this.radius=radius;
		this.height=height;
	}
	double getHeight()
	{
		return height;
	}
	double getVolume()
	{
		return getArea()*height;
	}
}
