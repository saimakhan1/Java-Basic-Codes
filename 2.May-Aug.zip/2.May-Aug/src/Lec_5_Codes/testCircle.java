package Lec_5_Codes;

public class testCircle {
	public static void main(String args[])
	{
		circle c1=new circle();
		circle c2=new circle(6);
		
		System.out.println("Radius is: "+c1.getRadius());
		System.out.println("Area is: "+c1.getArea());
		
		System.out.println("Radius is: "+c2.getRadius());
		System.out.println("Area is: "+c2.getArea());
	}

}
