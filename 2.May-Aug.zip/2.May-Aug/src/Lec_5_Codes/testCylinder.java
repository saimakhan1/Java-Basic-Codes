package Lec_5_Codes;

public class testCylinder {
	public static void main(String args[])
	{
		//cylinder c1=new cylinder();
		//cylinder c2=new cylinder(3);
		cylinder c3=new cylinder(4,5);
			
		/*System.out.println("Radius is "+c1.getRadius());
		System.out.println("Height is: "+c1.getHeight());
		System.out.println("Area is: "+c1.getArea());
		System.out.println("Volume is: "+c1.getVolume());*/
		
		/*System.out.println("Radius is "+c2.getRadius());
		System.out.println("Area is "+c2.getArea());
		System.out.println("Height is "+c2.getHeight());
		System.out.println("Volume is "+c2.getVolume());*/
		
		
		System.out.println("Radius is: "+c3.getRadius());
		System.out.println("Height is: "+c3.getHeight());
		System.out.println("Area is: "+c3.getArea());
		System.out.println("Volume is: "+c3.getVolume());
		
		
		
	}

}
