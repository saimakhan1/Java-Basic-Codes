package Lec_6_polymorphism;

public class HumanMeal {	
	void eat()
	{
		System.out.println("Human eat rice");
	}
}


