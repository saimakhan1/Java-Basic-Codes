package Lec_6_polymorphism;

public class KidsMeal extends HumanMeal{
	void eat()
	{
		System.out.println("Kids eat Chocolate");
	}
}
