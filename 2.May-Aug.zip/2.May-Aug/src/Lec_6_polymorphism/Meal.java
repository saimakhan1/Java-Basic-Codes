package Lec_6_polymorphism;

public class Meal {
	public static void main(String args[])
	{
		KidsMeal k1=new KidsMeal();
		HumanMeal h1=new HumanMeal();
		
		k1.eat();
		h1.eat();	
	}
}
