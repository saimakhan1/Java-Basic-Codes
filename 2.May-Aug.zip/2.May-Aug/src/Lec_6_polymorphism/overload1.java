package Lec_6_polymorphism;

public class overload1 {
	
	int add(int a, double b)
	{
		System.out.println("Hi! it's 1st add method ");
		return a;
	}
	int add(double a, int b)
	{
		System.out.println("Hi! it's 2nd add method ");
		return b;
	}
	
	/*int add(int a, int b)
	{
		System.out.println("Hi! it's 1st add method ");
		return a+b;
	}
	
	/*int add(double a, double b)
	{
		int c=10;
		double d=a+b;
		System.out.println("Hi! it's 2nd add method "+"sum="+d);
		return c;
	}
	/*int add(int a, int b,int c)
	{
		System.out.println("Hi! it's 2nd add method ");
		return a+b-c;
	}
	
	/*int add(int a, int b, float c)
	{
		System.out.println("Hello! it's 2nd method! ");
		return a+b;
	}

	int add(float a, int b, int c)
	{
		System.out.println("Hello! it's 3rd method! ");
		return b;
	}
	
	int add(int a, int b, int c,int d)
	{
		System.out.println("Hello! it's 3rd method! ");
		return a;
	}*/
	

}
