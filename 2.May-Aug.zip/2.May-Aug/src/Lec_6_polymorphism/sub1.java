package Lec_6_polymorphism;

public class sub1 extends super1{
	
	
	void sing()
	{
		System.out.println("Method of sub class");
	}

}
