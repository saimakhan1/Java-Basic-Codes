package Lec_6_polymorphism;

public class super1 {
	
	
	void sing()
	{
		System.out.println("Method of superclass");
	}

}
