package Lec_6_polymorphism;

public class testOverload1 {
	
	public static void main(String args[])
	{
		overload1 o1=new overload1();
		System.out.println("Result= "+o1.add(2,3.4));
		System.out.println("Result= "+o1.add(2.4,3));
		
		//System.out.println("Addition= "+o1.add(2,3));
		//System.out.println("Addition= "+o1.add(2.4,3.4));
		//System.out.println("Addition= "+o1.add(2,3,4));
		//System.out.println("Add2= "+o1.add(2,3,4));

	}
	

}
