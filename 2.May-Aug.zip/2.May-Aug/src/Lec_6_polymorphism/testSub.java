package Lec_6_polymorphism;

public class testSub {
	public static void main(String args[])
	{
		sub1 s1=new sub1();
		
		super1 s3=new super1();
		
		s1.sing();
		//s2.sing();
		s3.sing();
		
	}
	
}
