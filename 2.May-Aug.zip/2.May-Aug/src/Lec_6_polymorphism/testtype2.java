package Lec_6_polymorphism;

public class testtype2 {
	public static void main(String args[])
	{
		type2 o1=new type2();
		//o1.display(2, 3);
		o1.display(2, 30.2f, 20.2f);
		//o1.display(2, 30.2, 20.2);
		
	}

}
