package Lec_6_polymorphism;

public class testtype_promotion1 {
	public static void main(String args[])
	{
		type_promotion1 o1=new type_promotion1();
		o1.display(2, 30.2f,20.2f);
		
	}

}
