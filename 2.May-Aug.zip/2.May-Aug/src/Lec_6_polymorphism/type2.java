package Lec_6_polymorphism;

public class type2 {
	
	void display(int a, double b)
	{
		System.out.println("Method A");
	}
	
	void display(int a, double b, double c)
	{
		System.out.println("Method B");
	}
	void display(int a, float b, float c)
	{
		System.out.println("Method C");
	}

}
