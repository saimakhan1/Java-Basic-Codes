package Lec_6_polymorphism;

public class type_promotion1 {

	void display(int a, double b)
	{
		System.out.println("Method A");
	}
	void display(int a, double b, double c)
	{
		System.out.println("Method B");
	}
}
