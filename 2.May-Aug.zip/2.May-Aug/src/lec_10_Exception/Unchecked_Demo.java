package lec_10_Exception;

public class Unchecked_Demo {
	   
	   public static void main(String args[]) {
	      int num[] = {1, 2, 3, 4};
	      System.out.println(num[5]);
	   }
	}