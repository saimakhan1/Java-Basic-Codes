package lec_10_Exception;
// Arithmetic Exception
public class a00 {
	public static void main(String args[])
	{
		try {
			int a[]=new int [5];
			a[4]=30/0;
			
		}
		catch(ArithmeticException e1)
		{
			System.out.print("Hello! Arithmatic Exception Occurred ");
		}

	}

}
