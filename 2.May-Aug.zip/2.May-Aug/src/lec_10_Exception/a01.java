package lec_10_Exception;
// Array Index out bounds exception 
public class a01 {
	public static void main(String args[])
	{
		try {
			int a[]=new int [5];	
			System.out.print("value="+a[7]);		
		}

		
		catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.print("Hi! ArrayIndexOutOfBoundsException- Exception Occurs");
		}		

	}

}
