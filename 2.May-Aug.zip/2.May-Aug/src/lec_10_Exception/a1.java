package lec_10_Exception;
//multiple catch block
public class a1 {
	public static void main(String args[])
	{
		try {
			int a[]=new int [5];
			a[4]=30/0;
			System.out.println(a[9]);
			
		}

		catch(ArithmeticException e1)
		{
			System.out.print("Hello! Arithmatic Exception Occurred ");
		}
		catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.print("Hi! ArrayIndexOutOfBoundsException- Exception Occurs");
		}
		catch(Exception e)
		{
			System.out.print("Hey! Exception Occurs"+e);

		}

	}

}
