package lec_10_Exception;
// use of try, catch and finally 
public class a2 {
	
	public static void main(String args[])
	{
		int num[]= {1,2,3,4,5};
		try {
			System.out.println(num[7]);	
		}
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
		
		finally {
			int a=num[2];
			System.out.println("Finally Exceuted!"+num[2]);
		}
		
		System.out.println("Congrats!");
		
	}

}
