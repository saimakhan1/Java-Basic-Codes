package lec_10_Exception;
// use of only try and finally 
public class a3 {
	
	public static void main(String args[])
	{
		try {
			int num[]= {1,2,3,4,5};
			System.out.println(num[6]);
		}
		finally {
			System.out.println("Done");
		}
		System.out.print("Hello!");
	}

}