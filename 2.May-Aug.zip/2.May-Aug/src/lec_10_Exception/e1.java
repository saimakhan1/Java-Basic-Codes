package lec_10_Exception;

public class e1 {

}
