package lec_10_Exception;

import java.io.*;
import java.util.Scanner;

//checked exception if...

public class e2 {
	
	public static void main(String args[]) throws IOException
	{
		File temp=new File("file.txt");
		Scanner file=new Scanner(temp);
		
		//Scanner file=new Scanner(new File("file.txt"));
		
		System.out.println(file.nextLine());
		System.out.println(file.nextLine());
		//System.out.println(file.nextLine());
		
	}

}
