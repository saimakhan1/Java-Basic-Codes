package lec_10_Exception;

//unchecked exception

public class e3 {
	
	public static void main(String args[])
	{
		int num[]= {1,2,3,4};
		
		System.out.println(num[5]);
	}

}
