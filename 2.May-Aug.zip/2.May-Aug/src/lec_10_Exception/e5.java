package lec_10_Exception;
//multiple catch block

public class e5 {
	
	public static void main(String args[])
	{
		try
		{
			int a[]=new int[5];
			a[7]=30/0;
			//a[4]=1;
			//a[5]=1;
		}
		
		catch(ArithmeticException e1)
		{
			System.out.println("Arithmetic exception occurs");
		}
		
		catch(ArrayIndexOutOfBoundsException e2)
		{
			System.out.println("ArrayIndexOutOfBoundsException e");
		}
		
		catch(Exception e)
		{
			System.out.println("Parent Exception Occurs");
		}
		
		System.out.println("rest of the code");
	}

}
