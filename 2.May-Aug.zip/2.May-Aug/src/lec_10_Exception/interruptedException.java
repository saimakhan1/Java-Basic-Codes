package lec_10_Exception;

public class interruptedException {
	
	public static void main(String args[]) throws InterruptedException
	{
		for(int i=0;i<3;i++)
		{
			System.out.println("Hello");
			Thread.sleep(2050);
			System.out.println("Hi");
			Thread.sleep(2050);
		}	
	}
}
