package lec_10_Exception;

public class numberFormat {

	   public static void main(String args[])
	   {
	      try{
		 int num=Integer.parseInt ("ABC") ;
		 System.out.println(num);
	      }catch(NumberFormatException e){
		  System.out.println("Number format exception occurred");
	       }
	   }
	}