package lec_10_Exception;

public class p1 {
	//We cannot handle runtime exception using throws keyword
	public static void main(String args[]) throws ArithmeticException
	{
		for(int i=0;i<3;i++)
		{
			int a=2;
			int b=0;
			int c=a/b;
			System.out.println("c "+c);
		}	
	}
}
