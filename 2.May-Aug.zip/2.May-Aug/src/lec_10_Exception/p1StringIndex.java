package lec_10_Exception;

public class p1StringIndex {
	
	   public static void main(String args[])
	   {
	      try{
	    	  String str="Hello Bangladesh";
	    	  System.out.println("String length is: "+str.length());;
	    	  
	    	  char a = str.charAt(40);
	    	  System.out.println(a);
	      }
	      catch(StringIndexOutOfBoundsException e)
	      {
	    	  System.out.println("StringIndexOutOfBoundsException!");
	      }
	   }
	}