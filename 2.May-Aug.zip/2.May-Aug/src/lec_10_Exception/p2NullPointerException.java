package lec_10_Exception;

public class p2NullPointerException {
	
	   public static void main(String args[])
	   {
		try{
			String str=null;
			System.out.println (str.length());
		}
	        catch(NullPointerException e){
			System.out.println("NullPointerException!");
		}
	   }
	}