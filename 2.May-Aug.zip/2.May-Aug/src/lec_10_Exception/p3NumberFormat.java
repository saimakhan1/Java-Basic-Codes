package lec_10_Exception;

public class p3NumberFormat {

	   public static void main(String args[])
	   {
	      try{
		 int num=Integer.parseInt ("abc") ;
		 System.out.println(num);
	      }catch(NumberFormatException e){
		  System.out.println("Number format exception occurred");
	       }
	   }
	}