package lec_10_Exception;
/*When you don�t handle exception 
 * and instead declare it at all the places*/

	class Exp1{  
		 void method()throws ArithmeticException{  
		  throw new ArithmeticException("\nHello!\nArithmeticException Occurred\n");  
		 }  
		}  
	public class p5ThrowThrows2 {  
		   public static void main(String args[])throws ArithmeticException{
			   Exp1 obj=new Exp1();  
		     obj.method();  
		  
		    System.out.println("End Of Program");  
		  }  
		}
