package lec_10_Exception;

public class throwexample {	
	static void checkEligibility(int student_age, int student_weight)
	{
		if(student_age<10 && student_weight<40)
			throw new ArithmeticException("student is not eligible for registration");
	
		else 
			System.out.println("Student entry is valid");	
	}

	public static void main(String args[])
	{
		System.out.println("welcome to registration process");
		checkEligibility(13,45);
		System.out.println("Have a nice day!");
	}
}


