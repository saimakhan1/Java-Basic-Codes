package lec_11_Exception2;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

//file write

public class File1 {
	
	public static void main(String args[])
	{
		File f1=new File("a.txt");
		File f2=new File("b.txt");
		File f3=new File("A:/java_file/c.txt");
		
		
		try {
			f1.createNewFile();
			f2.createNewFile();
			f3.createNewFile();
			System.out.println("Files Creation Successful!");
			
			PrintWriter p1=new PrintWriter(f1);
			p1.println("Hello");
			p1.println(45);
			p1.close();
			
			PrintWriter p2=new PrintWriter(f2);
			p2.println("Hello Bangladesh!");
			p2.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
