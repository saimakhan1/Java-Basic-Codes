package lec_11_Exception2;
import java.io.File; 
import java.util.Scanner; 
//file read
public class File2
{ 
  public static void main(String[] args) throws Exception 
  { 
    // pass the path to the file as a parameter 
    File file = 
      new File("B:\\7. Java Codes\\2. May-Aug\\b.txt"); 
    Scanner sc = new Scanner(file); 
  
    while (sc.hasNextLine()) 
      System.out.println(sc.nextLine()); 
  } 
} 