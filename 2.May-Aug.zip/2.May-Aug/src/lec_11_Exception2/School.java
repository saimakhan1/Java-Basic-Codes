package lec_11_Exception2;

public class School {
	// here you must add the keyword static
	static void checkEligibility(int age, int student_weight)
	{
		if(age<5 || student_weight<25)
			throw new ArithmeticException("Student is not Eligible");
		else
			System.out.println("Student Entry Valid");
	}
	
	public static void main(String args[])
	{
		System.out.println("Welcome to Registration...");
		checkEligibility(23, 26);
		//checkEligibility(3, 39);
		System.out.println("Well Done");
		
	}

}
