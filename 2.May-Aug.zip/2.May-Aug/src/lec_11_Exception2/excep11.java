package lec_11_Exception2;
import java.util.Scanner;

class excep11
{
public static void main (String args[])
{
System.out.println("Enter two numbers");
Scanner s = new Scanner (System.in);
int x = s.nextInt();
int y = s.nextInt();
int z = x/y;
System.out.println("result of division is : " + z);
}
}