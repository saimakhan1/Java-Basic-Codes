package lec_11_Exception2;

class throws1 
{ 
    public static void main(String[] args) throws InterruptedException 
    { 
        Thread.sleep(250); 
        System.out.println("Hello World"); 
    } 
} 
