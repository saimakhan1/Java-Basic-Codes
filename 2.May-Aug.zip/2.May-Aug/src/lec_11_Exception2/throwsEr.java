package lec_11_Exception2;

class throwsEr 
{ 
    public static void main(String[] args) 
    { 
        //Thread.sleep(10000); 
        System.out.println("Hello Geeks"); 
    } 
} 
