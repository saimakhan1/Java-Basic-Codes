package lec_12_Thread;

class class1 extends Thread{
	
	public void run()
	{
		for(int i=0;i<10;i++)
			System.out.println("Value: "+i);
	}

}
public class testClass{
	public static void main(String args[])
	{
		class1 obj=new class1();
		obj.start();
		class1 obj2=new class1();
		obj2.start();
	}
}
