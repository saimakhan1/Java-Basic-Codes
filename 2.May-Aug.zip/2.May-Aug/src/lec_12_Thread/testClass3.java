package lec_12_Thread;

class class3 extends Thread{
	
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("Thread ID: "+ Thread.currentThread().getId()
					+" Value: " +i);
			try {
				Thread.sleep(150);
			}
			catch(InterruptedException e)
			{
				System.out.println("Exception Occurs!");
			}
		}

	}

}
public class testClass3{
	public static void main(String args[])
	{
		class3 obj=new class3();
		obj.start();
		class3 obj2=new class3();
		obj2.start();
	}
}
