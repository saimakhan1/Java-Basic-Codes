package lec_13_Thread;

class test2 extends Thread{
	public void run()
	{
		System.out.println("Thread ID: "+
	Thread.currentThread().getId()+
	", Thread Name: "
	+Thread.currentThread().getName());
	}
}

public class ThreadNaming {

	public static void main(String args[])
	{
		test2 t1=new test2();
		test2 t2=new test2();
		
		t1.setName("Nova");
		t2.setName("Thomas");
		
		t1.start();
		t2.start();
	}
}
