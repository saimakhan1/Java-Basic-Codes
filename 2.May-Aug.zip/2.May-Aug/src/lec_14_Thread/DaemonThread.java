package lec_14_Thread;

class test2 extends Thread{
	public void run()
	{
		System.out.println(Thread.currentThread().getName()+
				" "+Thread.currentThread().isDaemon());
	}
}

public class DaemonThread {
	public static void main(String args[])
	{
		test2 t1=new test2();
		test2 t2=new test2();
		
		t1.setName("Daemon Scott");
		t2.setName("Daemon Colorado");
	
		t1.setDaemon(true);
		
		t1.start();
		t2.start();
		
	}

}
