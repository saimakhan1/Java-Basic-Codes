package lec_14_Thread;

public class Deadlock {
	
	public static void main(String args[])
	{
		String resource1="printer";
		String resource2="RAM";
		String resource3="register";
	
		Thread t1=new Thread() {
			public void run()
			{
				synchronized(resource1){
					System.out.println("Thread-1 locked resource1 "+resource1);
				}
				try {
					Thread.sleep(200);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				synchronized(resource2){
					System.out.println("Thread-1 locked resource2 "+resource2);
				}
				synchronized(resource3){
					System.out.println("Thread-1 locked resource3 "+resource3);
				}
			}
		};
		
		
		Thread t2=new Thread() {
			public void run()
			{
				synchronized(resource1){
					System.out.println("Thread-2 locked resource1 "+resource1);
				}
				synchronized(resource2){
					System.out.println("Thread-2 locked resource2 "+resource2);
				}
				try {
					Thread.sleep(200);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				synchronized(resource3){
					System.out.println("Thread-2 locked resource3 "+resource3);
				}
			}
		};
		
		Thread t3=new Thread() {
			public void run()
			{
				synchronized(resource1){
					System.out.println("Thread-3 locked resource1 "+resource1);
				}
				synchronized(resource2){
					System.out.println("Thread-3 locked resource2 "+resource2);
				}
				try {
					Thread.sleep(200);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				synchronized(resource3){
					System.out.println("Thread-3 locked resource3 "+resource3);
				}
			}
		};
		
		t1.start();
		t2.start();
		t3.start();
	}

}
