package lec_14_Thread;

class test1 extends Thread{
	public void run()
	{
		for(int i=1;i<=3;i++)
			try {
				System.out.println(Thread.currentThread().getId()+" i= "+i);
				Thread.sleep(200);
			}
		catch(Exception e)
		{
			System.out.println(e);
		}
		//System.out.println("i= "+i);
	}
}

public class JoinThread {

	public static void main(String args[])
	{
		test1 thread1=new test1();
		test1 thread2=new test1();
		test1 thread3=new test1();
		test1 thread4=new test1();
		test1 thread5=new test1();
		
		thread1.start();
		thread2.start();
		/*try {
			thread2.join();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}*/
		
		thread3.start();
		thread4.start();
		
		try {
			thread4.join();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		thread5.start();
	}
}
