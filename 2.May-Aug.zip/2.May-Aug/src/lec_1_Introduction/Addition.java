package lec_1_Introduction;

public class Addition {
		
	int add(int a, int b)
	{
		int sum=a+b;
		return sum;
	}

}
