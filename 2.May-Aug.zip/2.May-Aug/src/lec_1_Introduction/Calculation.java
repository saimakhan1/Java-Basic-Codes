package lec_1_Introduction;

public class Calculation {
	
	public static void main(String args[])
	{

		
		Addition a1=new Addition(); // object creation 
		int sum1=a1.add(20, 10); // object called by passing 2 parameters 
		
		System.out.println("Sum= "+sum1);// print the value of sum from Addition method 
	}

}
