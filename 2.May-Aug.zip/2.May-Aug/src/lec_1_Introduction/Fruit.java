package lec_1_Introduction;

public class Fruit {
	
	public static void main(String args[])
	{
		
		Mango m1=new Mango();

		m1.color();

	}

}
