package lec_1_Introduction;

public class Mango {
	
	void color()
	{
		String color;
		color="Yellow";
		System.out.print("Mango color is "+ color);
	}

}
