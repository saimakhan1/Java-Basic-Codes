package lec_1_Introduction;

public class Multiplication {

}
