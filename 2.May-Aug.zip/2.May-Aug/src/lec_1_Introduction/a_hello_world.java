package lec_1_Introduction;

public class a_hello_world {
	
	public static void main(String args[])
	{
		System.out.println("Hello World");
	}

}
