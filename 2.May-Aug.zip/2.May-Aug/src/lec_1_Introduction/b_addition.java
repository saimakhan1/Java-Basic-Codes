package lec_1_Introduction;

public class b_addition {
	
	public static void main(String args[])
	{
		int a,b,sum;
		char d;
		d='y';
		a=2;
		b=4;
		sum=a+b;
		System.out.println("Sum="+sum);
		
	}	
}
