package lec_1_Introduction;

import java.util.Scanner;

public class c_addition_input2 {
	
	public static void main(String args[])
	{
		int a,b,sum;
		
	    Scanner input = new Scanner(System.in);
	    
	    a = input.nextInt(); // to take integer input, use nextInt
	    b = input.nextInt(); 
	    
		sum=a+b;
		System.out.println("sum= "+sum);

	}
	
}
