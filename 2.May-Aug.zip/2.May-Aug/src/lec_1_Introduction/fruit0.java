package lec_1_Introduction;
// 1 class, 1 method

class green_Mango
{
	void color()
	{
		String color;
		color="Yellow";
		System.out.println("Color is: "+color);	
	}
	void color(int a)
	{
		
		String color="red";
	}
	
}

public class fruit0 {
	
	public static void main(String args[])
	{
		Mango m1=new Mango();
		
		m1.color();	
	}
}
