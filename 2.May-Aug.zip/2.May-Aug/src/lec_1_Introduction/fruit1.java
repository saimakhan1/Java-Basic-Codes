package lec_1_Introduction;
// 1 class, 2 methods
class apple
{
	String color1;
	void color()
	{
		
		color1="red";
		
		System.out.println(color1);
	
	}
	
	String taste()
	{
		return "sweet";
	}
}


public class fruit1 {
	
	public static void main(String args[])
	{
		apple a1=new apple();
		a1.color();
		System.out.println(a1.taste());
	}

}
