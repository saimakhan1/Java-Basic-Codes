package lec_1_Introduction;
// 2 class, multiple methods in each class

class Banana
{
	String color()
	{
		return "yellow";
	}
	
	String taste()
	{
		return "sweet";
	}
	int weight()
	{
		return 20;
	}
}

class Grape
{
	String color()
	{
		return "purple";
	}
	String taste()
	{
		return "sour";
	}
	
}

public class fruit2 {
	public static void main(String args[])
	{
		Banana b1=new Banana();
		Grape g1=new Grape();
		
		System.out.println(b1.color());
		System.out.println(b1.weight());
	
		System.out.println("The color of Grape is "+g1.color());
		System.out.println("The taste of Grape is "+g1.taste());
	}
	
	
}
