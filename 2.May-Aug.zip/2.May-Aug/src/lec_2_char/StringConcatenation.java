package lec_2_char;

public class StringConcatenation {
	public static void main(String args[])
	{
		String s1="play";
		System.out.print("I "+s1+" football.");
	}

}
