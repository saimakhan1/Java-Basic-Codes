package lec_2_char;
//print a simple string

public class StringDemo {
	public static void main(String args[])
	{
		char array1[]= {'H','E','L','L','O'};
		String s1=new String(array1);
		System.out.println(s1);
	}
}
