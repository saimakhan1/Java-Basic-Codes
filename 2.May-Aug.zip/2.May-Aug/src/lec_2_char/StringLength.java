package lec_2_char;

public class StringLength {
	public static void main(String args[])
	{
		String s1="Hello Java";
		int len=s1.length();
		System.out.println("The length is: "+ len);
	
	}
	
}
