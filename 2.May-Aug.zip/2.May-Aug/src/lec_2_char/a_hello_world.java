package lec_2_char;

public class a_hello_world {
	
	public static void main(String args[])
	{
		System.out.println("hi World");
	}

}
