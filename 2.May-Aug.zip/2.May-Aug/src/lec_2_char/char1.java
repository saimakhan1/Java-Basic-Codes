package lec_2_char;

class char1
{
	public static void main (String args[])
	{
		char ch1, ch2;
		ch1=88;
		ch2='Y';
		System.out.println ("ch1 and ch2: " + ch1+ " "+ch2);
	} 
}
