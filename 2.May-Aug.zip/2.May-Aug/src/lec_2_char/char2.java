package lec_2_char;

class char2
{
	public static void main (String args[])
	{
		char ch1;
		ch1= 'X';
		System.out.println ("ch1 contains "+ch1);
		ch1--;
		System.out.println ("ch1 is now " + ch1);
		
		System.out.println("10>9 is "+(10>9));
		System.out.println("8>9 is "+(8>9));
	}
}

