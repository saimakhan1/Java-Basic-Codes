package lec_2_char;

public class max1 {
	public static void main(String args[])
	{
		int []a=new int [5];
		a[0]=100; 
		a[1]=30;
		a[2]=22;
		a[3]=220;
		a[4]=420;
		int i,total=0,max=a[0];
		for(i=1;i<a.length;i++)
			if(a[i]>max)
			{
				max=a[i];
			}
			System.out.println(max);
	}
	

}
