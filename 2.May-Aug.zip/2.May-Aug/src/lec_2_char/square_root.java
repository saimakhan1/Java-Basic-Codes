package lec_2_char;

public class square_root {
	public static void main (String args [])
	{
		double x=5, y;
		y = Math.sqrt(x);
		System.out.println("Y= "+y);
	}


}
