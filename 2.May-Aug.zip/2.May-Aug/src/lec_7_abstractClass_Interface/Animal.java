package lec_7_abstractClass_Interface;

public abstract class Animal {
	
	abstract void food();
	abstract void sound();
	abstract int age();
	
	void welcome()
	{
		System.out.println("Welcome to Animal Shop");
	}
	

}

class Dog extends Animal{
	
	void food()
	{
		System.out.println("Bone");
	}
	void sound()
	{
		System.out.println("Bark");
	}
	int age(int age1)
	{
		age1=10;
		return age1;
	}
	
	
}