package lec_7_abstractClass_Interface;

public class Demo implements my_interface1{
	public void method1()
	{
		System.out.println("Method 1 from my 1st interface");
	}

	public void method2()
	{
		System.out.print("Method 2 from my 1st interface");	
	}
	public static void main(String args[])
	{
		my_interface1 obj=new Demo();
		obj.method1();
		obj.method2();
	}
}
