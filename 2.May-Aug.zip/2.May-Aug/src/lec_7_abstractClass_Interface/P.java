package lec_7_abstractClass_Interface;

 interface P {
	 public void mp();

}
 
 interface Q {
	 public double mp();

} 
