package lec_7_abstractClass_Interface;
/*
public class R implements P,Q{
/*
	
	public double mp()
	{
		System.out.print("Hello");
	}
	public void mp()
	{
		System.out.print("Hello");
	}
	public static void main(String args[])
	{
		
	}
}

*/