package lec_7_abstractClass_Interface;

interface X{
	int a=5;
}
interface Y{
	int a=50;
}
public class Z implements X,Y {
	public static void main(String args[])
	{
		//System.out.print(a);
		System.out.println(X.a);
		System.out.println(Y.a);
	}
}
