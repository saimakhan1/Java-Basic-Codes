package lec_7_abstractClass_Interface;

 interface a {
	public void m1();
	public void m2();

}

 interface b {
	public void m1();

}
