package lec_7_abstractClass_Interface;

public abstract class a1 {
	
	abstract void display();
		
	
	
	
	
	void display1()
	{
		System.out.println("Concrete");
	}
	
	public static void main(String args[])
	{
		//a1 obj=new a1();// if you try to create object, it will show error
	}

}
