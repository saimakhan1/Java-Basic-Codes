package lec_7_abstractClass_Interface;

public interface batch_52 {
	
	 void java();
	 
	 void sing();
	


}
