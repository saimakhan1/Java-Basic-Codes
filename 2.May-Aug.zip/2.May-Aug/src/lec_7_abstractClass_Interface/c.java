package lec_7_abstractClass_Interface;

public class c implements a,b{
	
	public void m1()
	{
		System.out.println("interface method m1");
	}
	public void m2()
	{
		System.out.println("interface method m2");
	}
	public static void main(String args[])
	{
		a obj1=new c();
		obj1.m2();
		a obj2=new c();
		obj1.m1();


		
	}

}
