package lec_7_abstractClass_Interface;

public interface i1 {
	public void method1();
	int a=10;

	
}

interface i2 extends i1{
	public void method2();
}

interface i3{
	public void method3();
}


