package lec_7_abstractClass_Interface;

public interface my_interface1 {
	public void method1();
	
	public void method2();

}
