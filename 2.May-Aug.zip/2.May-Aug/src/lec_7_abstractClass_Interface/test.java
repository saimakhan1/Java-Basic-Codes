package lec_7_abstractClass_Interface;

public class test implements i2{
	
	public void method1()
	{
		System.out.println("Hello");
	}
	public void method2()
	{
		System.out.println("Hi");
	}
	public static void main(String args[])
	{
		i2 obj=new test();
		obj.method2();
		obj.method1();
	}
}
