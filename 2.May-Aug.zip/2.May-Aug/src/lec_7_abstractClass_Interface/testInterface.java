package lec_7_abstractClass_Interface;

public interface testInterface {

}
