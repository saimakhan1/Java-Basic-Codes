package lec_7_abstractClass_Interface;

public class testTry1 implements try1{
	public static void main(String args[])
	{
	//	a=12;
	}
}
