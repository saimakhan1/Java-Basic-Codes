package lec_7_abstractClass_Interface;

public interface try1 {
	int a=10;
	public static final int b=12;
	
	//int c;--> error
}
