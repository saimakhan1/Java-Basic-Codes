package lec_8_encapsulation;

public class Author {
	String name, email;
	char gender;
	
	
	String getName()
	{
		return name;
	}
	
	String getEmail()
	{
		return email;
	}
	
	char getGender()
	{
		return gender;
	}
	void setName(String value)
	{
		 name=value;
	}
	
	void setEmail(String value)
	{
		email=value;
	}
	
	void setGender(char value)
	{
		 gender=value;
	}

}
