package lec_8_encapsulation;

public class EncapsulationDemo {
	
	private int id, age;
	private String name;
	
	public int getID()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
	public int getAge()
	{
		return age;
	}
	
	public void setID(int value)
	{
		id=value;
	}
	
	public void setName(String value)
	{
		name=value;
	}
	
	public void setAge(int value)
	{
		age=value;
	}

}
