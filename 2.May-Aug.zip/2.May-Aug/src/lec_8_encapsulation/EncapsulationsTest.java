package lec_8_encapsulation;

public class EncapsulationsTest {
	
	public static void main(String args[])
	{
		EncapsulationDemo d1=new EncapsulationDemo();
		
		d1.setName("Tani");
		d1.setID(25576);
		d1.setAge(20);
		
		System.out.println("Student Name: "+d1.getName());
		System.out.println("Student ID: "+d1.getID());
		System.out.println("Student Age: "+d1.getAge());
	}

}
