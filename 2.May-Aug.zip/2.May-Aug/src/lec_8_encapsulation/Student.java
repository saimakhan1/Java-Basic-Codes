package lec_8_encapsulation;

class Student{  
	 int roll_no;  
	 String name,city;  
	 
	 Student(int roll_no, String name, String city)
	 {  
		 this.roll_no=roll_no;  
		 this.name=name;  
		 this.city=city;  
	 }  
	   
	 public String toString(){//overriding the toString() method  
	  return roll_no+" "+name+" "+city; 
	 }  
	 public static void main(String args[]){  
	   Student s1=new Student(1001,"Tani","Dhanmondi");  
	   Student s2=new Student(1002,"Rini","Elephant Road");  
	     
	   System.out.println(s1);//compiler writes here s1.toString()  
	   System.out.println(s2);//compiler writes here s2.toString()  
	 }  
	}  
