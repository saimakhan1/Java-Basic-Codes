package lec_9_OOP_Exercices;

public class Box {
	
	private double width;
	private double height;
	private double depth;
	
	
	Box(double w, double h, double d)//constructor used when all dimensions specified
	{
		width=w;
		height=h;
		depth=d;
	}
	
	
	double volume()
	{
		return width*height*depth;
	}

}
