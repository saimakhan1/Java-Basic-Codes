package lec_9_OOP_Exercices;

public class BoxWeight extends Box{

	double weight;
	
	
	BoxWeight(double w, double h, double d, double m)
	{
		super(w,h,d);//call superclass constructor
		weight=m;
	}
	
	}
