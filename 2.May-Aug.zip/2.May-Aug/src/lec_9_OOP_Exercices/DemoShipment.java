package lec_9_OOP_Exercices;

public class DemoShipment {
	
	public static void main(String args[])
	{
		Shipment s1=new Shipment(10,20,15,10, 3.41);
		
		Shipment s2=new Shipment(2,3,4,0.76,1.28);
		
		double vol;
		
		vol=s1.volume();
		
		System.out.println("Volume of shipment1 is:"+vol);
		System.out.println("Weight of shipment1 is "+s1.weight);
		
		System.out.println("Shipping cost: $"+s1.cost);
		System.out.println();
		
		vol=s2.volume();
		
		System.out.println("Volume of shipment1 is:"+vol);
		System.out.println("Weight of shipment1 is "+s2.weight);
		
		System.out.println("Shipping cost: $"+s2.cost);
		System.out.println();
		
	}
		
}
