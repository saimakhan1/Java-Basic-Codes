package lec_9_OOP_Exercices;

public class Test { 

	   public static void main(String args[]) {
	      Integer p = 7;

	      System.out.println(p.toString());  
	      System.out.println(Integer.toString(12)); 
	   }
	}