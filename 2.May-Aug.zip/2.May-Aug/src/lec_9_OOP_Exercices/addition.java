package lec_9_OOP_Exercices;

public class addition {
	int a,  b, c;
	int add(int a, int b)
	{
		this.a=a;
		this.b=b;
		return a+b;
	}
	int add(int a, int b, int c)
	{
		this.a=a;
		this.b=b;
		this.c=c;
		return a+b+c;
	}

}
