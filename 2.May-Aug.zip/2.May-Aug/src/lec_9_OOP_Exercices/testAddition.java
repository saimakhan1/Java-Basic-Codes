package lec_9_OOP_Exercices;

public class testAddition {
	
	public static void main(String args[])
	{
		addition a1=new addition();
		int b1=a1.add(10,20);
		int b2=a1.add(10, 20, 30);
		
		System.out.println("addition 1: "+b1+"\naddition 2: " +b2);
	}

}
