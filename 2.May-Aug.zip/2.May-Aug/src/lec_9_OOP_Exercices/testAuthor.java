package lec_9_OOP_Exercices;

public class testAuthor {
	
	public static void main(String args[])
	{
		Author a1=new Author();
		
		a1.setName("Tasnim");
		a1.setEmail("tasnim@gmail.com");
		a1.setGender('F');
		
		System.out.println("Student Name: "+a1.getName());
		System.out.println("Student Email: "+a1.getEmail());
		System.out.println("Student Gender: "+a1.getGender());

	}

}
