package mid_term51;

public class Cuboid extends Rectangle{
	
	double height;
	Cuboid()
	{
		height=2;
	}
	
	Cuboid(double length)
	{
		super();
	}
	Cuboid(double length, double width)
	{
		super();
	}
	Cuboid(double length, double width, double height)
	{
		super();
		this.height=height;
	}
	
	double getHeight()
	{
		return height;
	}

	double getVolume()
	{
		return getArea()*height;
	}

}
