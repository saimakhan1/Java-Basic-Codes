package mid_term51;

public class Rectangle {
	double length, width;
	
	Rectangle()
	{
		length=4;
		width=3;
	}
	Rectangle(double length, double width)
	{
		this.length=length;
		this.width=width;
	}
	
	double getLength()
	{
		return length;
	}
	double getWidth()
	{
		return width;
	}

	double getArea()
	{
		return length*width;
	}
}
