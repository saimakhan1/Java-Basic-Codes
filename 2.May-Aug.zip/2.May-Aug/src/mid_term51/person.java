package mid_term51;

public class person {
	String name, address;
	int phone_number;
	
	void name(String name)
	{
		System.out.println("Name: "+name);
	}
	
	void phone_number(int phone_number)
	{
		System.out.println("Phone: "+phone_number);
	}
	
	void address(String address)
	{
		System.out.println("Address: "+address);
	}

}
