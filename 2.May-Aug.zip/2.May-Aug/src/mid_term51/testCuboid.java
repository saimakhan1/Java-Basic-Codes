package mid_term51;

public class testCuboid {
	
	public static void main(String args[])
	{
		Cuboid cu1=new Cuboid();
		Cuboid cu2=new Cuboid(1,2,3);
		
		System.out.println(cu1.getArea());
		System.out.println(cu1.getVolume());
		
		System.out.println(cu2.getArea());
		System.out.println(cu2.getVolume());
		
	}

}
