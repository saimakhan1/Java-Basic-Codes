package mid_term51;

public class testPerson {
	
	public static void main(String args[])
	{
		person p1=new person();
		
		p1.name("Rini");
		p1.address("Blue Aveneue");
		p1.phone_number(988098);
		
	}
	
	
	

	

}
