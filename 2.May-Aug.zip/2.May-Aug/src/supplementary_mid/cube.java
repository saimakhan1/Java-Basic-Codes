package supplementary_mid;

public class cube extends square{

	cube(double length)
	{
		super(length);
			
	}
	
	double getVolume()
	{
		return getArea()*length;
	}
}
