package supplementary_mid;

public class square {

	double length;
	
	square()
	{
		
	}
	
	square(double length)
	{
		this.length=length;
	}
	
	double getArea()
	{
		return length*length;
	}
}
