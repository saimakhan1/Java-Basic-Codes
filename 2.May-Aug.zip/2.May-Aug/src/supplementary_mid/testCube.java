package supplementary_mid;

public class testCube {
	public static void main(String args[])
	{
		
		cube c1=new cube(2);
		
		System.out.println("Length "+c1.length);
		System.out.println("Area "+c1.getArea());
		System.out.println("Volume "+c1.getVolume());
	}

}
