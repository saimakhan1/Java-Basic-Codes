package tries;

public class Add2 {
	
	void add(int a, int b)
	{
		int sum;
		sum=a+b;
		System.out.println("sum= "+sum);
	}
	
	void add(float a, float b)
	{
		float sum;
		sum=a+b;
		System.out.println("sum= "+sum);
	}

}
