package tries;

public class TestOverloading2 {
	public static void main(String args[])
	{
		Add2 x=new Add2();
		x.add(2, 3);
		x.add(2.5f, 3.5f);
	}

}
